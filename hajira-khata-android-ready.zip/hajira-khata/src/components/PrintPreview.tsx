import {useEffect} from 'react';
import {FileSpreadsheet, Printer, X} from 'lucide-react';
import {HajiraState} from '../types';
import {
  BN_MONTHS,
  BN_WEEKDAYS_SHORT,
  getDaysInMonth,
  getMonthKey,
  getWeekdayIndex,
  isHoliday,
  toBn,
} from '../utils/bengali';

interface PrintPreviewProps {
  open: boolean;
  state: HajiraState;
  onClose: () => void;
  onDownloadExcel: () => void;
}

export function PrintPreview({
  open,
  state,
  onClose,
  onDownloadExcel,
}: PrintPreviewProps) {
  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  if (!open) return null;

  const {schoolName, className, month, year, students, attendance} = state;
  const monthKey = getMonthKey(year, month);
  const monthData = attendance[monthKey] ?? {marks: {}, hol: {}};
  const daysInMonth = getDaysInMonth(year, month);
  const days = Array.from({length: daysInMonth}, (_, i) => i + 1);
  const dayHolidays = days.map((d) => isHoliday(year, month, d, monthData.hol));

  const dailyPresent = new Array<number>(daysInMonth).fill(0);
  const dailyAbsent = new Array<number>(daysInMonth).fill(0);
  let grandPresent = 0;
  let grandAbsent = 0;

  const rowsData = students.map((stu) => {
    const stuMarks = monthData.marks[stu.id] ?? {};
    let p = 0;
    let a = 0;
    const cells = days.map((d, idx) => {
      if (dayHolidays[idx]) return 'ছু';
      const m = stuMarks[d];
      if (m === 'P') {
        p += 1;
        dailyPresent[idx] += 1;
        grandPresent += 1;
        return 'উ';
      }
      if (m === 'A') {
        a += 1;
        dailyAbsent[idx] += 1;
        grandAbsent += 1;
        return 'অ';
      }
      if (m === 'L') return 'ছু';
      return '';
    });
    const sum = p + a;
    const rate = sum > 0 ? `${toBn(Math.round((p / sum) * 100))}%` : '—';
    return {stu, cells, p, a, rate};
  });

  const grandSum = grandPresent + grandAbsent;
  const grandRate =
    grandSum > 0 ? `${toBn(Math.round((grandPresent / grandSum) * 100))}%` : '—';

  return (
    <div
      className="print-only-root fixed inset-0 z-50 bg-slate-200 overflow-auto p-2 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="প্রিন্ট প্রিভিউ"
    >
      {/* Controls bar hidden when printing */}
      <div className="no-print max-w-[1120px] mx-auto mb-3 flex flex-wrap items-center justify-between gap-2 bg-white text-slate-900 rounded-xl p-3 shadow-sm border border-slate-300">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="min-h-[44px] px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold inline-flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" aria-hidden="true" />
            <span>প্রিন্ট করুন</span>
          </button>

          <button
            type="button"
            onClick={onDownloadExcel}
            className="min-h-[44px] px-4 py-2 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold inline-flex items-center gap-1.5"
          >
            <FileSpreadsheet className="w-4 h-4" aria-hidden="true" />
            <span>Excel ডাউনলোড</span>
          </button>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="min-h-[44px] px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-900 text-sm font-semibold inline-flex items-center gap-1.5"
        >
          <X className="w-4 h-4" aria-hidden="true" />
          <span>বন্ধ করুন</span>
        </button>
      </div>

      {/* White A4 Landscape sheet */}
      <div className="print-sheet max-w-[1120px] mx-auto bg-white text-black p-4 sm:p-8 shadow-lg border border-slate-300">
        <div className="text-center mb-3">
          <h2 className="text-xl font-bold">{schoolName.trim() || 'স্কুলের নাম'}</h2>
          <p className="text-base font-bold mt-0.5">হাজিরা খাতা</p>
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm font-semibold mt-1">
            <span>শ্রেণি: {className.trim() || 'সপ্তম'}</span>
            <span>
              মাস: {BN_MONTHS[month - 1]} {toBn(year)}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="print-table w-full border-collapse text-[10px] sm:text-[11px]">
            <thead>
              <tr>
                <th className="border border-black px-1 py-1 text-center w-8">রোল</th>
                <th className="border border-black px-1.5 py-1 text-left min-w-[110px]">নাম</th>
                {days.map((d, idx) => (
                  <th
                    key={d}
                    className={`border border-black px-0.5 py-0.5 text-center tabular-nums ${
                      dayHolidays[idx] ? 'print-holiday-col bg-gray-200' : ''
                    }`}
                  >
                    <div>{toBn(d)}</div>
                    <div className="font-normal text-[9px]">
                      {BN_WEEKDAYS_SHORT[getWeekdayIndex(year, month, d)]}
                    </div>
                  </th>
                ))}
                <th className="border border-black px-1 py-1 text-center">উ</th>
                <th className="border border-black px-1 py-1 text-center">অ</th>
                <th className="border border-black px-1 py-1 text-center">হার</th>
              </tr>
            </thead>
            <tbody>
              {rowsData.map(({stu, cells, p, a, rate}) => (
                <tr key={stu.id}>
                  <td className="border border-black px-1 py-0.5 text-center tabular-nums">
                    {toBn(stu.roll)}
                  </td>
                  <td className="border border-black px-1.5 py-0.5 text-left">
                    {stu.name}
                  </td>
                  {cells.map((val, idx) => (
                    <td
                      key={idx}
                      className={`border border-black px-0.5 py-0.5 text-center ${
                        dayHolidays[idx] ? 'print-holiday-col bg-gray-200' : ''
                      }`}
                    >
                      {val}
                    </td>
                  ))}
                  <td className="border border-black px-1 py-0.5 text-center font-semibold tabular-nums">
                    {toBn(p)}
                  </td>
                  <td className="border border-black px-1 py-0.5 text-center font-semibold tabular-nums">
                    {toBn(a)}
                  </td>
                  <td className="border border-black px-1 py-0.5 text-center font-semibold tabular-nums">
                    {rate}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="font-semibold">
                <td colSpan={2} className="border border-black px-1.5 py-1 text-left">
                  দৈনিক উপস্থিত
                </td>
                {days.map((d, idx) => (
                  <td
                    key={d}
                    className={`border border-black px-0.5 py-1 text-center tabular-nums ${
                      dayHolidays[idx] ? 'print-holiday-col bg-gray-200' : ''
                    }`}
                  >
                    {dayHolidays[idx] ? 'ছু' : toBn(dailyPresent[idx])}
                  </td>
                ))}
                <td className="border border-black px-1 py-1 text-center tabular-nums">
                  {toBn(grandPresent)}
                </td>
                <td className="border border-black px-1 py-1 text-center">—</td>
                <td className="border border-black px-1 py-1 text-center">—</td>
              </tr>

              <tr className="font-semibold">
                <td colSpan={2} className="border border-black px-1.5 py-1 text-left">
                  দৈনিক অনুপস্থিত
                </td>
                {days.map((d, idx) => (
                  <td
                    key={d}
                    className={`border border-black px-0.5 py-1 text-center tabular-nums ${
                      dayHolidays[idx] ? 'print-holiday-col bg-gray-200' : ''
                    }`}
                  >
                    {dayHolidays[idx] ? 'ছু' : toBn(dailyAbsent[idx])}
                  </td>
                ))}
                <td className="border border-black px-1 py-1 text-center">—</td>
                <td className="border border-black px-1 py-1 text-center tabular-nums">
                  {toBn(grandAbsent)}
                </td>
                <td className="border border-black px-1 py-1 text-center">—</td>
              </tr>

              <tr className="font-semibold">
                <td colSpan={2} className="border border-black px-1.5 py-1 text-left">
                  দৈনিক হার
                </td>
                {days.map((d, idx) => {
                  if (dayHolidays[idx]) {
                    return (
                      <td
                        key={d}
                        className="border border-black px-0.5 py-1 text-center print-holiday-col bg-gray-200"
                      >
                        ছু
                      </td>
                    );
                  }
                  const p = dailyPresent[idx];
                  const a = dailyAbsent[idx];
                  const sum = p + a;
                  return (
                    <td
                      key={d}
                      className="border border-black px-0.5 py-1 text-center tabular-nums text-[9px]"
                    >
                      {sum > 0 ? `${toBn(Math.round((p / sum) * 100))}%` : '—'}
                    </td>
                  );
                })}
                <td className="border border-black px-1 py-1 text-center">—</td>
                <td className="border border-black px-1 py-1 text-center">—</td>
                <td className="border border-black px-1 py-1 text-center tabular-nums">
                  {grandRate}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="mt-12 pt-4 flex items-center justify-between text-xs sm:text-sm font-semibold">
          <div className="border-t border-black pt-1.5 px-6">শ্রেণি শিক্ষকের স্বাক্ষর</div>
          <div className="border-t border-black pt-1.5 px-6">প্রধান শিক্ষকের স্বাক্ষর</div>
        </div>
      </div>
    </div>
  );
}
