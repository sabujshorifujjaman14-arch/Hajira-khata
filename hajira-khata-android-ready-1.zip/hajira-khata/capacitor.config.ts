import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hajirakhata.app',
  appName: 'হাজিরা খাতা',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
