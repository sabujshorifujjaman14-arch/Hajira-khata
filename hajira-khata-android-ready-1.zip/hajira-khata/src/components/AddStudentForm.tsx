import {FormEvent, useEffect, useState} from 'react';
import {UserPlus} from 'lucide-react';
import {parseBnOrEnInt, toBn} from '../utils/bengali';

interface AddStudentFormProps {
  suggestedRoll: number;
  onAddStudent: (roll: number, name: string) => void;
}

export function AddStudentForm({suggestedRoll, onAddStudent}: AddStudentFormProps) {
  const [rollText, setRollText] = useState(() => toBn(suggestedRoll));
  const [nameText, setNameText] = useState('');

  useEffect(() => {
    setRollText(toBn(suggestedRoll));
  }, [suggestedRoll]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const parsedRoll = parseBnOrEnInt(rollText);
    const finalRoll = parsedRoll !== null && parsedRoll > 0 ? parsedRoll : suggestedRoll;
    onAddStudent(finalRoll, nameText.trim());
    setNameText('');
  };

  return (
    <section
      aria-label="নতুন শিক্ষার্থী যোগ"
      className="no-print bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs p-3.5 sm:p-4"
    >
      <form onSubmit={handleSubmit} className="flex flex-wrap sm:flex-nowrap items-end gap-2.5">
        <div className="w-24 shrink-0">
          <label
            htmlFor="add-stu-roll"
            className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1"
          >
            রোল
          </label>
          <input
            id="add-stu-roll"
            type="text"
            inputMode="numeric"
            value={rollText}
            onChange={(e) => setRollText(e.target.value)}
            placeholder={toBn(suggestedRoll)}
            className="w-full min-h-[44px] px-3 py-2 text-sm text-center rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 tabular-nums"
          />
        </div>

        <div className="flex-1 min-w-[160px]">
          <label
            htmlFor="add-stu-name"
            className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1"
          >
            শিক্ষার্থীর নাম
          </label>
          <input
            id="add-stu-name"
            type="text"
            value={nameText}
            onChange={(e) => setNameText(e.target.value)}
            placeholder="নাম লিখুন"
            className="w-full min-h-[44px] px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
          />
        </div>

        <button
          type="submit"
          className="min-h-[44px] px-4 py-2 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors"
        >
          <UserPlus className="w-4 h-4" aria-hidden="true" />
          <span>যোগ করুন</span>
        </button>
      </form>
    </section>
  );
}
