import {ChangeEvent, useEffect, useRef, useState} from 'react';
import {Copy, Download, RotateCcw, Upload} from 'lucide-react';
import {BackupMode, HajiraState} from '../types';
import {
  analyzeTextBackup,
  generateAllMonthsBackupJson,
  generateDailyBackupText,
  generateMonthlyBackupText,
} from '../utils/backup';
import {
  BN_MONTHS,
  BN_WEEKDAYS_FULL,
  getDaysInMonth,
  getWeekdayIndex,
  toBn,
} from '../utils/bengali';
import {copyTextToClipboard, saveAndShareFile} from '../utils/capacitorBridge';
import {
  exportMonthToXlsxBytes,
  getExcelFilename,
  restoreFromExcelBuffer,
} from '../utils/excel';

interface BackupCardProps {
  state: HajiraState;
  onRestoreState: (nextState: HajiraState) => void;
}

export function BackupCard({state, onRestoreState}: BackupCardProps) {
  const daysInMonth = getDaysInMonth(state.year, state.month);
  const [selectedDay, setSelectedDay] = useState<number>(() => {
    const today = new Date();
    if (today.getFullYear() === state.year && today.getMonth() + 1 === state.month) {
      return Math.min(today.getDate(), daysInMonth);
    }
    return 1;
  });

  useEffect(() => {
    setSelectedDay((prev) => Math.min(Math.max(1, prev), daysInMonth));
  }, [daysInMonth]);

  const [backupMode, setBackupMode] = useState<BackupMode | null>(null);
  const [outputText, setOutputText] = useState('');
  const [copyStatus, setCopyStatus] = useState<string | null>(null);

  const [pasteText, setPasteText] = useState('');
  const [pendingJsonRestore, setPendingJsonRestore] = useState<HajiraState | null>(null);
  const [restoreFeedback, setRestoreFeedback] = useState<{
    type: 'success' | 'error' | 'warn';
    text: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const showCopyNotice = (msg: string) => {
    setCopyStatus(msg);
    window.setTimeout(() => {
      setCopyStatus((curr) => (curr === msg ? null : curr));
    }, 3000);
  };

  const handleGenerateBackup = async (mode: BackupMode) => {
    let text = '';
    if (mode === 'daily') {
      text = generateDailyBackupText(state, selectedDay);
    } else if (mode === 'monthly') {
      text = generateMonthlyBackupText(state);
    } else {
      text = generateAllMonthsBackupJson(state);
    }
    setBackupMode(mode);
    setOutputText(text);
    const copied = await copyTextToClipboard(text);
    showCopyNotice(copied ? 'ক্লিপবোর্ডে কপি হয়েছে।' : 'বক্সে তৈরি হয়েছে, কপি করতে পারেন।');
  };

  const handleCopyAgain = async () => {
    if (!outputText) return;
    const copied = await copyTextToClipboard(outputText);
    showCopyNotice(copied ? 'আবার ক্লিপবোর্ডে কপি হয়েছে।' : 'কপি করা যায়নি।');
  };

  const handleSaveAsFile = async () => {
    const activeMode: BackupMode = backupMode ?? 'daily';
    const monthStr = String(state.month).padStart(2, '0');
    const dayStr = String(selectedDay).padStart(2, '0');

    if (activeMode === 'daily') {
      const content = outputText || generateDailyBackupText(state, selectedDay);
      const res = await saveAndShareFile({
        filename: `hajira-${state.year}-${monthStr}-${dayStr}.txt`,
        mimeType: 'text/plain;charset=utf-8',
        data: content,
      });
      showCopyNotice(res.ok ? 'দৈনিক ফাইল সংরক্ষণ সম্পন্ন।' : res.error || 'সংরক্ষণ ব্যর্থ হয়েছে।');
    } else if (activeMode === 'monthly') {
      const bytes = exportMonthToXlsxBytes(state);
      const res = await saveAndShareFile({
        filename: getExcelFilename(state.year, state.month),
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        data: bytes,
      });
      showCopyNotice(res.ok ? 'মাসিক Excel ফাইল সংরক্ষণ সম্পন্ন।' : res.error || 'সংরক্ষণ ব্যর্থ হয়েছে।');
    } else {
      const content = outputText || generateAllMonthsBackupJson(state);
      const res = await saveAndShareFile({
        filename: `hajira-backup-all-${state.year}-${monthStr}.json`,
        mimeType: 'application/json;charset=utf-8',
        data: content,
      });
      showCopyNotice(res.ok ? 'সম্পূর্ণ ব্যাকআপ JSON সংরক্ষণ সম্পন্ন।' : res.error || 'সংরক্ষণ ব্যর্থ হয়েছে।');
    }
  };

  const handleTextRestoreClick = () => {
    // If waiting for second confirmation tap for JSON restore:
    if (pendingJsonRestore) {
      onRestoreState(pendingJsonRestore);
      setPendingJsonRestore(null);
      setPasteText('');
      setRestoreFeedback({
        type: 'success',
        text: 'সব মাসের সম্পূর্ণ ব্যাকআপ সফলভাবে ফিরিয়ে আনা হয়েছে।',
      });
      return;
    }

    const analysis = analyzeTextBackup(pasteText, state);
    if (analysis.kind === 'error') {
      setRestoreFeedback({type: 'error', text: analysis.error});
      return;
    }
    if (analysis.kind === 'json') {
      setPendingJsonRestore(analysis.state);
      setRestoreFeedback({
        type: 'warn',
        text: 'নিশ্চিত হলে আবার চাপুন। এখনকার সব তথ্য বদলে যাবে।',
      });
      return;
    }
    if (analysis.kind === 'daily-txt') {
      onRestoreState(analysis.nextState);
      setPasteText('');
      setRestoreFeedback({type: 'success', text: analysis.message});
    }
  };

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setPendingJsonRestore(null);
    const lowerName = file.name.toLowerCase();

    if (lowerName.endsWith('.xlsx') || lowerName.endsWith('.xls')) {
      const buffer = await file.arrayBuffer();
      const result = restoreFromExcelBuffer(buffer, state);
      if (result.ok) {
        onRestoreState(result.nextState);
        setRestoreFeedback({type: 'success', text: result.message});
      } else if ('error' in result) {
        setRestoreFeedback({type: 'error', text: result.error});
      }
      return;
    }

    if (lowerName.endsWith('.json') || lowerName.endsWith('.txt')) {
      const text = await file.text();
      setPasteText(text);
      const analysis = analyzeTextBackup(text, state);
      if (analysis.kind === 'error') {
        setRestoreFeedback({type: 'error', text: analysis.error});
      } else if (analysis.kind === 'json') {
        setPendingJsonRestore(analysis.state);
        setRestoreFeedback({
          type: 'warn',
          text: 'নিশ্চিত হলে আবার চাপুন। এখনকার সব তথ্য বদলে যাবে।',
        });
      } else if (analysis.kind === 'daily-txt') {
        onRestoreState(analysis.nextState);
        setPasteText('');
        setRestoreFeedback({type: 'success', text: analysis.message});
      }
      return;
    }

    setRestoreFeedback({
      type: 'error',
      text: 'শুধুমাত্র .xlsx, .json অথবা .txt ফাইল নির্বাচন করুন।',
    });
  };

  return (
    <section
      aria-label="ব্যাকআপ ও পুনরুদ্ধার"
      className="no-print bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs p-3.5 sm:p-5 space-y-4"
    >
      <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100">
        ব্যাকআপ
      </h2>

      {/* Export / Generate controls */}
      <div className="flex flex-wrap items-center gap-2">
        <label htmlFor="backup-day-select" className="sr-only">
          তারিখ নির্বাচন
        </label>
        <select
          id="backup-day-select"
          value={selectedDay}
          onChange={(e) => setSelectedDay(Number(e.target.value))}
          className="min-h-[44px] px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
        >
          {Array.from({length: daysInMonth}, (_, idx) => {
            const d = idx + 1;
            const wd = BN_WEEKDAYS_FULL[getWeekdayIndex(state.year, state.month, d)];
            return (
              <option key={d} value={d}>
                {toBn(d)} {BN_MONTHS[state.month - 1]} ({wd})
              </option>
            );
          })}
        </select>

        <button
          type="button"
          onClick={() => handleGenerateBackup('daily')}
          className={`min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold border transition-colors ${
            backupMode === 'daily'
              ? 'bg-teal-600 text-white border-teal-600'
              : 'bg-teal-50 text-teal-800 border-teal-200 hover:bg-teal-100 dark:bg-teal-950/50 dark:text-teal-200 dark:border-teal-800'
          }`}
        >
          দৈনিক ব্যাকআপ
        </button>

        <button
          type="button"
          onClick={() => handleGenerateBackup('monthly')}
          className={`min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold border transition-colors ${
            backupMode === 'monthly'
              ? 'bg-blue-600 text-white border-blue-600'
              : 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100 dark:bg-blue-950/50 dark:text-blue-200 dark:border-blue-800'
          }`}
        >
          মাসিক ব্যাকআপ
        </button>

        <button
          type="button"
          onClick={() => handleGenerateBackup('all')}
          className={`min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold border transition-colors ${
            backupMode === 'all'
              ? 'bg-slate-700 text-white border-slate-700'
              : 'bg-slate-100 text-slate-800 border-slate-300 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700'
          }`}
        >
          সব মাসের ব্যাকআপ
        </button>
      </div>

      {/* Output textarea */}
      <div className="space-y-2">
        <textarea
          readOnly
          aria-label="ব্যাকআপের ফলাফল"
          value={outputText}
          rows={5}
          placeholder="উপরের যেকোনো একটি বোতামে চাপলে এখানে ব্যাকআপ দেখা যাবে এবং কপি হয়ে যাবে..."
          className="w-full p-3 text-xs sm:text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 font-mono resize-y"
        />

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={!outputText}
            onClick={handleCopyAgain}
            className="min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 transition-colors"
          >
            <Copy className="w-4 h-4" aria-hidden="true" />
            <span>আবার কপি করুন</span>
          </button>

          <button
            type="button"
            onClick={handleSaveAsFile}
            className="min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold bg-teal-600 hover:bg-teal-700 text-white inline-flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-4 h-4" aria-hidden="true" />
            <span>ফাইল হিসেবে সংরক্ষণ</span>
          </button>

          {copyStatus && (
            <span className="text-xs sm:text-sm font-semibold text-teal-700 dark:text-teal-300">
              {copyStatus}
            </span>
          )}
        </div>
      </div>

      {/* Restore section */}
      <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
        <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100">
          ব্যাকআপ থেকে ফিরিয়ে আনুন
        </h3>

        <div className="flex flex-wrap items-center gap-2.5">
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.json,.txt"
            onChange={handleFileChange}
            className="hidden"
            id="restore-file-input"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 dark:bg-blue-950/50 dark:text-blue-200 dark:border-blue-800 inline-flex items-center gap-1.5 transition-colors"
          >
            <Upload className="w-4 h-4" aria-hidden="true" />
            <span>ফাইল বাছাই করুন (.xlsx / .json / .txt)</span>
          </button>
        </div>

        <textarea
          aria-label="ব্যাকআপ লেখা পেস্ট করুন"
          value={pasteText}
          onChange={(e) => {
            setPasteText(e.target.value);
            setPendingJsonRestore(null);
            setRestoreFeedback(null);
          }}
          rows={3}
          placeholder="অথবা JSON / দৈনিক ব্যাকআপের লেখা এখানে পেস্ট করুন..."
          className="w-full p-3 text-xs sm:text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
        />

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleTextRestoreClick}
            className={`min-h-[44px] px-4 py-2 rounded-lg text-sm font-semibold inline-flex items-center gap-1.5 transition-colors ${
              pendingJsonRestore
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-slate-800 hover:bg-slate-900 text-white dark:bg-slate-700 dark:hover:bg-slate-600'
            }`}
          >
            <RotateCcw className="w-4 h-4" aria-hidden="true" />
            <span>
              {pendingJsonRestore ? 'নিশ্চিত হলে আবার চাপুন' : 'ফিরিয়ে আনুন'}
            </span>
          </button>

          {pendingJsonRestore && (
            <button
              type="button"
              onClick={() => {
                setPendingJsonRestore(null);
                setRestoreFeedback(null);
              }}
              className="min-h-[44px] px-3 py-2 rounded-lg text-sm font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
            >
              বাতিল
            </button>
          )}
        </div>

        {restoreFeedback && (
          <p
            role="status"
            className={`text-xs sm:text-sm font-semibold px-3 py-2 rounded-lg border ${
              restoreFeedback.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-200 dark:border-emerald-800'
                : restoreFeedback.type === 'warn'
                ? 'bg-amber-50 text-amber-900 border-amber-300 dark:bg-amber-950/60 dark:text-amber-200 dark:border-amber-800'
                : 'bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/60 dark:text-rose-200 dark:border-rose-800'
            }`}
          >
            {restoreFeedback.text}
          </p>
        )}
      </div>
    </section>
  );
}
