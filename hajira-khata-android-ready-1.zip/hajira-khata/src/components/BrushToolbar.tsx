import {FileSpreadsheet, Printer, Trash2} from 'lucide-react';
import {Mark} from '../types';

interface BrushToolbarProps {
  brush: Mark;
  deleteMode: boolean;
  onSelectBrush: (mark: Mark) => void;
  onDownloadExcel: () => void;
  onOpenPrintPreview: () => void;
  onToggleDeleteMode: () => void;
}

export function BrushToolbar({
  brush,
  deleteMode,
  onSelectBrush,
  onDownloadExcel,
  onOpenPrintPreview,
  onToggleDeleteMode,
}: BrushToolbarProps) {
  return (
    <section
      aria-label="হাজিরা ব্রাশ ও অ্যাকশন"
      className="no-print bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs p-3.5 sm:p-4 space-y-3"
    >
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        {/* Three brush pill buttons */}
        <div className="flex flex-wrap items-center gap-2" role="radiogroup" aria-label="দাগ দেওয়ার ব্রাশ">
          <button
            type="button"
            role="radio"
            aria-checked={brush === 'P'}
            onClick={() => onSelectBrush('P')}
            className={`min-h-[44px] px-3.5 py-2 rounded-full text-sm font-semibold border transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              brush === 'P'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800'
            }`}
          >
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-white/20 dark:bg-black/20 font-bold text-xs">
              উ
            </span>
            <span>উপস্থিত</span>
          </button>

          <button
            type="button"
            role="radio"
            aria-checked={brush === 'A'}
            onClick={() => onSelectBrush('A')}
            className={`min-h-[44px] px-3.5 py-2 rounded-full text-sm font-semibold border transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              brush === 'A'
                ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                : 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800'
            }`}
          >
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-white/20 dark:bg-black/20 font-bold text-xs">
              অ
            </span>
            <span>অনুপস্থিত</span>
          </button>

          <button
            type="button"
            role="radio"
            aria-checked={brush === 'L'}
            onClick={() => onSelectBrush('L')}
            className={`min-h-[44px] px-3.5 py-2 rounded-full text-sm font-semibold border transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              brush === 'L'
                ? 'bg-slate-600 text-white border-slate-600 shadow-xs'
                : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
            }`}
          >
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-white/25 dark:bg-black/25 font-bold text-xs">
              ছু
            </span>
            <span>ছুটি</span>
          </button>
        </div>

        {/* Utility action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onDownloadExcel}
            className="min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold bg-teal-600 hover:bg-teal-700 text-white transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
          >
            <FileSpreadsheet className="w-4 h-4" aria-hidden="true" />
            <span>শীট ডাউনলোড (Excel)</span>
          </button>

          <button
            type="button"
            onClick={onOpenPrintPreview}
            className="min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" aria-hidden="true" />
            <span>প্রিন্ট প্রিভিউ</span>
          </button>

          <button
            type="button"
            aria-pressed={deleteMode}
            onClick={onToggleDeleteMode}
            className={`min-h-[44px] px-3.5 py-2 rounded-lg text-sm font-semibold border transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5 ${
              deleteMode
                ? 'bg-rose-600 text-white border-rose-600'
                : 'bg-white dark:bg-slate-800 text-rose-700 dark:text-rose-300 border-rose-300 dark:border-rose-800 hover:bg-rose-50 dark:hover:bg-rose-950/40'
            }`}
          >
            <Trash2 className="w-4 h-4" aria-hidden="true" />
            <span>শিক্ষার্থী মুছুন</span>
          </button>
        </div>
      </div>

      <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
        নির্বাচিত ব্রাশ দিয়ে ঘরে ট্যাপ করলে দাগ বসবে, একই ঘরে আবার ট্যাপ করলে দাগ মুছে যাবে। দিনের সংখ্যায় ট্যাপ করলে দিনের মেনু খুলবে।
      </p>
    </section>
  );
}
