import {useEffect} from 'react';
import {CalendarCheck, CalendarOff, CalendarPlus, Eraser, X} from 'lucide-react';
import {BN_MONTHS, BN_WEEKDAYS_FULL, getWeekdayIndex, toBn} from '../utils/bengali';

interface DayBottomSheetProps {
  day: number | null;
  month: number;
  year: number;
  isDayHoliday: boolean;
  onMarkAllPresent: (day: number) => void;
  onToggleHoliday: (day: number) => void;
  onClearDayMarks: (day: number) => void;
  onClose: () => void;
}

export function DayBottomSheet({
  day,
  month,
  year,
  isDayHoliday,
  onMarkAllPresent,
  onToggleHoliday,
  onClearDayMarks,
  onClose,
}: DayBottomSheetProps) {
  useEffect(() => {
    if (day === null) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [day, onClose]);

  if (day === null) return null;

  const weekdayName = BN_WEEKDAYS_FULL[getWeekdayIndex(year, month, day)];

  return (
    <div
      className="no-print fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-[1px]"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`${toBn(day)} তারিখের হাজিরা বিকল্প`}
    >
      <div
        className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl border-t sm:border border-slate-200 dark:border-slate-700 shadow-xl p-4 pb-6 sm:pb-4 space-y-3"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto sm:hidden" />

        <div className="flex items-center justify-between gap-2 pb-1 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100">
              {toBn(day)} {BN_MONTHS[month - 1]} {toBn(year)}
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              {weekdayName} {isDayHoliday ? '· ছুটির দিন' : '· কার্যদিবস'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="বন্ধ করুন"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="space-y-2.5">
          <button
            type="button"
            onClick={() => {
              onMarkAllPresent(day);
              onClose();
            }}
            className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
          >
            <CalendarCheck className="w-4 h-4" aria-hidden="true" />
            <span>সবাইকে উপস্থিত দিন</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onToggleHoliday(day);
              onClose();
            }}
            className={`w-full min-h-[48px] px-4 py-2.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 border transition-colors ${
              isDayHoliday
                ? 'bg-teal-50 hover:bg-teal-100 text-teal-800 border-teal-300 dark:bg-teal-950/60 dark:text-teal-200 dark:border-teal-800'
                : 'bg-amber-100 hover:bg-amber-200 text-amber-950 border-amber-300 dark:bg-amber-900/50 dark:text-amber-100 dark:border-amber-700'
            }`}
          >
            {isDayHoliday ? (
              <>
                <CalendarPlus className="w-4 h-4" aria-hidden="true" />
                <span>ছুটি বাতিল করুন</span>
              </>
            ) : (
              <>
                <CalendarOff className="w-4 h-4" aria-hidden="true" />
                <span>এই দিন ছুটি করুন</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              onClearDayMarks(day);
              onClose();
            }}
            className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 dark:bg-rose-950/50 dark:text-rose-200 dark:border-rose-800 font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
          >
            <Eraser className="w-4 h-4" aria-hidden="true" />
            <span>এই দিনের দাগ মুছুন</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 font-semibold text-sm transition-colors"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
}
