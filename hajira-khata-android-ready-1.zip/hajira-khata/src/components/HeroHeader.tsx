import {BN_MONTHS, toBn} from '../utils/bengali';

interface HeroHeaderProps {
  schoolName: string;
  className: string;
  month: number;
  year: number;
}

export function HeroHeader({schoolName, className, month, year}: HeroHeaderProps) {
  const displaySchool = schoolName.trim() || 'স্কুলের নাম';
  const displayClass = className.trim() || 'সপ্তম';
  const displayMonth = BN_MONTHS[month - 1] ?? BN_MONTHS[0];
  const displayYear = toBn(year);

  return (
    <header className="no-print bg-gradient-to-r from-teal-600 via-teal-600 to-blue-600 dark:from-teal-800 dark:via-teal-800 dark:to-blue-900 text-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 sm:py-5">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight leading-tight">
          হাজিরা খাতা
        </h1>
        <p className="mt-1 text-sm sm:text-base text-teal-50/95 font-medium truncate">
          {displaySchool} · শ্রেণি {displayClass} · {displayMonth} {displayYear}
        </p>
      </div>
    </header>
  );
}
