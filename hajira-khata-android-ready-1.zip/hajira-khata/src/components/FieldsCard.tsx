import {useEffect, useState} from 'react';
import {ChevronLeft, ChevronRight} from 'lucide-react';
import {BN_MONTHS, parseBnOrEnInt, toBn} from '../utils/bengali';

interface FieldsCardProps {
  schoolName: string;
  className: string;
  month: number;
  year: number;
  onChangeSchoolName: (value: string) => void;
  onChangeClassName: (value: string) => void;
  onChangeMonthYear: (month: number, year: number) => void;
}

export function FieldsCard({
  schoolName,
  className,
  month,
  year,
  onChangeSchoolName,
  onChangeClassName,
  onChangeMonthYear,
}: FieldsCardProps) {
  const [yearDraft, setYearDraft] = useState(() => toBn(year));

  useEffect(() => {
    setYearDraft(toBn(year));
  }, [year]);

  const handlePrevMonth = () => {
    if (month === 1) {
      onChangeMonthYear(12, Math.max(1900, year - 1));
    } else {
      onChangeMonthYear(month - 1, year);
    }
  };

  const handleNextMonth = () => {
    if (month === 12) {
      onChangeMonthYear(1, Math.min(2200, year + 1));
    } else {
      onChangeMonthYear(month + 1, year);
    }
  };

  const handleYearChange = (val: string) => {
    setYearDraft(val);
    const parsed = parseBnOrEnInt(val);
    if (parsed !== null && parsed >= 1900 && parsed <= 2200) {
      onChangeMonthYear(month, parsed);
    }
  };

  const handleYearBlur = () => {
    const parsed = parseBnOrEnInt(yearDraft);
    if (parsed !== null && parsed >= 1900 && parsed <= 2200) {
      onChangeMonthYear(month, parsed);
      setYearDraft(toBn(parsed));
    } else {
      setYearDraft(toBn(year));
    }
  };

  return (
    <section
      aria-label="বিদ্যালয় ও মাসের তথ্য"
      className="no-print bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs p-3.5 sm:p-4"
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="min-w-0">
          <label
            htmlFor="field-school-name"
            className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1"
          >
            স্কুলের নাম
          </label>
          <input
            id="field-school-name"
            type="text"
            value={schoolName}
            onChange={(e) => onChangeSchoolName(e.target.value)}
            placeholder="স্কুলের নাম লিখুন"
            className="w-full min-h-[44px] px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
          />
        </div>

        <div className="min-w-0">
          <label
            htmlFor="field-class-name"
            className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1"
          >
            শ্রেণি
          </label>
          <input
            id="field-class-name"
            type="text"
            value={className}
            onChange={(e) => onChangeClassName(e.target.value)}
            placeholder="যেমন: সপ্তম"
            className="w-full min-h-[44px] px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500"
          />
        </div>

        <div className="min-w-0">
          <label
            htmlFor="field-month-select"
            className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1"
          >
            মাসের নাম
          </label>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handlePrevMonth}
              aria-label="আগের মাস"
              className="min-w-[44px] min-h-[44px] shrink-0 flex items-center justify-center rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" aria-hidden="true" />
            </button>
            <select
              id="field-month-select"
              value={month}
              onChange={(e) => onChangeMonthYear(Number(e.target.value), year)}
              className="w-full min-w-0 min-h-[44px] px-2.5 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
            >
              {BN_MONTHS.map((mName, idx) => (
                <option key={mName} value={idx + 1}>
                  {mName}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={handleNextMonth}
              aria-label="পরের মাস"
              className="min-w-[44px] min-h-[44px] shrink-0 flex items-center justify-center rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 transition-colors"
            >
              <ChevronRight className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>
        </div>

        <div className="min-w-0">
          <label
            htmlFor="field-year"
            className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1"
          >
            সাল
          </label>
          <input
            id="field-year"
            type="text"
            inputMode="numeric"
            value={yearDraft}
            onChange={(e) => handleYearChange(e.target.value)}
            onBlur={handleYearBlur}
            placeholder="২০২৬"
            className="w-full min-h-[44px] px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 tabular-nums"
          />
        </div>
      </div>
    </section>
  );
}
