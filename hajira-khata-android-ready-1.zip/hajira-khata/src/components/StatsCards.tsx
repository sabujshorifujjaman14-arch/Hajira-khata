import {MonthAttendance, Student} from '../types';
import {getDaysInMonth, isHoliday, toBn} from '../utils/bengali';

interface StatsCardsProps {
  year: number;
  month: number;
  students: Student[];
  monthData: MonthAttendance;
}

export function StatsCards({year, month, students, monthData}: StatsCardsProps) {
  const daysInMonth = getDaysInMonth(year, month);

  let workingDays = 0;
  let takenDays = 0;
  let totalPresent = 0;
  let totalAbsent = 0;

  for (let d = 1; d <= daysInMonth; d += 1) {
    if (isHoliday(year, month, d, monthData.hol)) {
      continue;
    }
    workingDays += 1;
    let dayHasAnyMark = false;

    for (const stu of students) {
      const m = monthData.marks[stu.id]?.[d];
      if (m) {
        dayHasAnyMark = true;
        if (m === 'P') totalPresent += 1;
        else if (m === 'A') totalAbsent += 1;
      }
    }

    if (dayHasAnyMark) {
      takenDays += 1;
    }
  }

  const totalPA = totalPresent + totalAbsent;
  const avgRate =
    totalPA > 0 ? `${toBn(Math.round((totalPresent / totalPA) * 100))}%` : '—';
  const avgDailyPresent =
    takenDays > 0 ? `${toBn((totalPresent / takenDays).toFixed(1))} জন` : '০.০ জন';
  const avgDailyAbsent =
    takenDays > 0 ? `${toBn((totalAbsent / takenDays).toFixed(1))} জন` : '০.০ জন';

  const cards = [
    {
      label: 'গড় উপস্থিতির হার',
      value: avgRate,
      cardClass:
        'bg-teal-50 border-teal-200 text-teal-900 dark:bg-teal-950/50 dark:border-teal-800 dark:text-teal-100',
      labelClass: 'text-teal-700 dark:text-teal-300',
    },
    {
      label: 'দিনে গড় উপস্থিত',
      value: avgDailyPresent,
      cardClass:
        'bg-emerald-50 border-emerald-200 text-emerald-900 dark:bg-emerald-950/50 dark:border-emerald-800 dark:text-emerald-100',
      labelClass: 'text-emerald-700 dark:text-emerald-300',
    },
    {
      label: 'দিনে গড় অনুপস্থিত',
      value: avgDailyAbsent,
      cardClass:
        'bg-rose-50 border-rose-200 text-rose-900 dark:bg-rose-950/50 dark:border-rose-800 dark:text-rose-100',
      labelClass: 'text-rose-700 dark:text-rose-300',
    },
    {
      label: 'কার্যদিবস',
      value: `${toBn(workingDays)} দিন`,
      cardClass:
        'bg-amber-50 border-amber-200 text-amber-900 dark:bg-amber-950/50 dark:border-amber-800 dark:text-amber-100',
      labelClass: 'text-amber-700 dark:text-amber-300',
    },
    {
      label: 'হাজিরা নেওয়া হয়েছে',
      value: `${toBn(takenDays)} দিন`,
      cardClass:
        'bg-blue-50 border-blue-200 text-blue-900 dark:bg-blue-950/50 dark:border-blue-800 dark:text-blue-100',
      labelClass: 'text-blue-700 dark:text-blue-300',
    },
  ];

  return (
    <section
      aria-label="মাসিক গড় পরিসংখ্যান"
      className="no-print grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3"
    >
      {cards.map((card) => (
        <div
          key={card.label}
          className={`rounded-xl border p-3.5 shadow-xs ${card.cardClass}`}
        >
          <div className={`text-xs font-semibold ${card.labelClass}`}>{card.label}</div>
          <div className="mt-1 text-xl sm:text-2xl font-bold tabular-nums">{card.value}</div>
        </div>
      ))}
    </section>
  );
}
