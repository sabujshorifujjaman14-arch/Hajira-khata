import {useEffect, useState} from 'react';
import {Mark, MonthAttendance, Student} from '../types';
import {
  BN_WEEKDAYS_SHORT,
  getDaysInMonth,
  getWeekdayIndex,
  isHoliday,
  parseBnOrEnInt,
  toBn,
} from '../utils/bengali';

interface AttendanceTableProps {
  year: number;
  month: number;
  students: Student[];
  monthData: MonthAttendance;
  deleteMode: boolean;
  onTapCell: (studentId: string, day: number) => void;
  onOpenDaySheet: (day: number) => void;
  onUpdateStudentRoll: (studentId: string, roll: number) => void;
  onUpdateStudentName: (studentId: string, name: string) => void;
  onDeleteStudent: (studentId: string) => void;
}

function RollCellInput({
  roll,
  onCommit,
}: {
  roll: number;
  onCommit: (nextRoll: number) => void;
}) {
  const [focused, setFocused] = useState(false);
  const [draft, setDraft] = useState(() => toBn(roll));

  useEffect(() => {
    if (!focused) {
      setDraft(toBn(roll));
    }
  }, [roll, focused]);

  return (
    <input
      type="text"
      inputMode="numeric"
      aria-label={`রোল ${toBn(roll)}`}
      value={focused ? draft : toBn(roll)}
      onFocus={(e) => {
        setFocused(true);
        setDraft(toBn(roll));
        e.currentTarget.select();
      }}
      onChange={(e) => {
        const val = e.target.value;
        setDraft(val);
        const parsed = parseBnOrEnInt(val);
        if (parsed !== null && parsed > 0) {
          onCommit(parsed);
        }
      }}
      onBlur={() => {
        setFocused(false);
        const parsed = parseBnOrEnInt(draft);
        if (parsed !== null && parsed > 0) {
          onCommit(parsed);
          setDraft(toBn(parsed));
        } else {
          setDraft(toBn(roll));
        }
      }}
      className="w-full h-9 px-1 text-center text-xs sm:text-sm font-semibold bg-transparent text-slate-900 dark:text-slate-100 rounded border border-transparent hover:border-slate-300 dark:hover:border-slate-600 focus:border-teal-600 focus:bg-white dark:focus:bg-slate-800 tabular-nums"
    />
  );
}

export function AttendanceTable({
  year,
  month,
  students,
  monthData,
  deleteMode,
  onTapCell,
  onOpenDaySheet,
  onUpdateStudentRoll,
  onUpdateStudentName,
  onDeleteStudent,
}: AttendanceTableProps) {
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  useEffect(() => {
    if (!deleteMode) {
      setConfirmDeleteId(null);
    }
  }, [deleteMode]);

  const daysInMonth = getDaysInMonth(year, month);
  const days = Array.from({length: daysInMonth}, (_, i) => i + 1);

  const dayHolidays = days.map((d) => isHoliday(year, month, d, monthData.hol));
  const dailyPresent = new Array<number>(daysInMonth).fill(0);
  const dailyAbsent = new Array<number>(daysInMonth).fill(0);

  let grandPresent = 0;
  let grandAbsent = 0;

  const studentStats = students.map((stu) => {
    const stuMarks = monthData.marks[stu.id] ?? {};
    let pCount = 0;
    let aCount = 0;

    days.forEach((d, idx) => {
      if (dayHolidays[idx]) return;
      const m = stuMarks[d];
      if (m === 'P') {
        pCount += 1;
        dailyPresent[idx] += 1;
        grandPresent += 1;
      } else if (m === 'A') {
        aCount += 1;
        dailyAbsent[idx] += 1;
        grandAbsent += 1;
      }
    });

    const totalPA = pCount + aCount;
    const rate = totalPA > 0 ? `${toBn(Math.round((pCount / totalPA) * 100))}%` : '—';
    return {pCount, aCount, rate};
  });

  const grandTotalPA = grandPresent + grandAbsent;
  const grandRate =
    grandTotalPA > 0 ? `${toBn(Math.round((grandPresent / grandTotalPA) * 100))}%` : '—';

  const handleDeleteClick = (studentId: string) => {
    if (confirmDeleteId === studentId) {
      onDeleteStudent(studentId);
      setConfirmDeleteId(null);
    } else {
      setConfirmDeleteId(studentId);
    }
  };

  return (
    <section
      aria-label="মাসিক হাজিরা তালিকা"
      className="no-print bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden"
    >
      <div className="overflow-x-auto overscroll-x-contain">
        <table className="w-max min-w-full border-collapse text-xs sm:text-sm">
          <thead>
            <tr className="bg-blue-700 dark:bg-blue-900 text-white">
              <th
                scope="col"
                className="sticky left-0 z-20 w-[52px] min-w-[52px] max-w-[52px] bg-blue-700 dark:bg-blue-900 border-b border-r border-blue-500/60 dark:border-blue-700 px-1 py-2 text-center font-bold"
              >
                রোল
              </th>
              <th
                scope="col"
                className="sticky left-[52px] z-20 w-[136px] min-w-[136px] max-w-[136px] sm:w-[176px] sm:min-w-[176px] sm:max-w-[176px] bg-blue-700 dark:bg-blue-900 border-b border-r border-blue-500/60 dark:border-blue-700 px-2 py-2 text-left font-bold shadow-[2px_0_5px_-2px_rgba(0,0,0,0.28)]"
              >
                নাম
              </th>
              {days.map((d, idx) => {
                const hol = dayHolidays[idx];
                const wd = BN_WEEKDAYS_SHORT[getWeekdayIndex(year, month, d)];
                return (
                  <th
                    key={d}
                    scope="col"
                    className={`border-b border-r border-blue-500/50 dark:border-blue-700 p-0 min-w-[38px] ${
                      hol
                        ? 'bg-amber-300 text-amber-950 dark:bg-amber-700 dark:text-amber-50'
                        : 'bg-blue-700 dark:bg-blue-900 text-white'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => onOpenDaySheet(d)}
                      aria-label={`${toBn(d)} তারিখ (${wd}) মেনু`}
                      className="w-full min-h-[46px] px-1 py-1 flex flex-col items-center justify-center leading-tight hover:bg-black/10 dark:hover:bg-white/10 transition-colors tabular-nums"
                    >
                      <span className="font-bold text-xs sm:text-sm">{toBn(d)}</span>
                      <span className="text-[11px] opacity-90">{wd}</span>
                    </button>
                  </th>
                );
              })}
              <th
                scope="col"
                className="border-b border-r border-blue-500/60 dark:border-blue-700 px-2 py-2 text-center font-bold min-w-[44px] bg-blue-800 dark:bg-blue-950"
              >
                উ
              </th>
              <th
                scope="col"
                className="border-b border-r border-blue-500/60 dark:border-blue-700 px-2 py-2 text-center font-bold min-w-[44px] bg-blue-800 dark:bg-blue-950"
              >
                অ
              </th>
              <th
                scope="col"
                className="border-b border-blue-500/60 dark:border-blue-700 px-2 py-2 text-center font-bold min-w-[54px] bg-blue-800 dark:bg-blue-950"
              >
                হার
              </th>
            </tr>
          </thead>

          <tbody>
            {students.length === 0 ? (
              <tr>
                <td
                  colSpan={daysInMonth + 5}
                  className="px-4 py-8 text-center text-slate-500 dark:text-slate-400"
                >
                  কোনো শিক্ষার্থী নেই। নিচের ফর্ম থেকে নতুন শিক্ষার্থী যোগ করুন।
                </td>
              </tr>
            ) : (
              students.map((stu, rowIdx) => {
                const isEven = rowIdx % 2 === 1;
                const rowBg = isEven
                  ? 'bg-emerald-50 dark:bg-emerald-950/35'
                  : 'bg-white dark:bg-slate-900';
                const stickyBg = isEven
                  ? 'bg-[#ecfdf5] dark:bg-[#07261c]'
                  : 'bg-white dark:bg-slate-900';
                const stuMarks = monthData.marks[stu.id] ?? {};
                const stats = studentStats[rowIdx];

                return (
                  <tr key={stu.id} className={`${rowBg} border-b border-slate-200 dark:border-slate-800`}>
                    <td
                      className={`sticky left-0 z-10 w-[52px] min-w-[52px] max-w-[52px] ${stickyBg} border-r border-slate-200 dark:border-slate-800 p-0.5 align-middle`}
                    >
                      <RollCellInput
                        roll={stu.roll}
                        onCommit={(nextRoll) => onUpdateStudentRoll(stu.id, nextRoll)}
                      />
                    </td>

                    <td
                      className={`sticky left-[52px] z-10 w-[136px] min-w-[136px] max-w-[136px] sm:w-[176px] sm:min-w-[176px] sm:max-w-[176px] ${stickyBg} border-r border-slate-200 dark:border-slate-800 px-1 py-0.5 align-middle shadow-[2px_0_5px_-2px_rgba(0,0,0,0.12)]`}
                    >
                      <div className="flex items-center gap-1 min-w-0">
                        <input
                          type="text"
                          aria-label={`রোল ${toBn(stu.roll)} নাম`}
                          value={stu.name}
                          onChange={(e) => onUpdateStudentName(stu.id, e.target.value)}
                          placeholder="নাম লিখুন"
                          className="w-full min-w-0 h-9 px-1.5 text-xs sm:text-sm bg-transparent text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 rounded border border-transparent hover:border-slate-300 dark:hover:border-slate-600 focus:border-teal-600 focus:bg-white dark:focus:bg-slate-800"
                        />
                        {deleteMode && (
                          <button
                            type="button"
                            onClick={() => handleDeleteClick(stu.id)}
                            aria-label={`${stu.name || `রোল ${toBn(stu.roll)}`} মুছুন`}
                            className={`shrink-0 min-h-[32px] px-1.5 rounded text-xs font-bold transition-colors whitespace-nowrap ${
                              confirmDeleteId === stu.id
                                ? 'bg-rose-600 text-white'
                                : 'bg-rose-100 text-rose-700 hover:bg-rose-200 dark:bg-rose-900/60 dark:text-rose-200'
                            }`}
                          >
                            {confirmDeleteId === stu.id ? 'মুছবেন?' : '✕'}
                          </button>
                        )}
                      </div>
                    </td>

                    {days.map((d, idx) => {
                      const hol = dayHolidays[idx];
                      if (hol) {
                        return (
                          <td
                            key={d}
                            className="border-r border-slate-200 dark:border-slate-800 p-0 bg-amber-100 dark:bg-amber-900/40 text-amber-900 dark:text-amber-200 text-center align-middle select-none"
                          >
                            <div className="w-full h-10 flex items-center justify-center font-semibold text-xs">
                              ছু
                            </div>
                          </td>
                        );
                      }

                      const mark: Mark | undefined = stuMarks[d];
                      let cellLabel = '';
                      let cellStyle =
                        'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800';
                      if (mark === 'P') {
                        cellLabel = 'উ';
                        cellStyle =
                          'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 dark:bg-emerald-900/65 dark:text-emerald-200 dark:hover:bg-emerald-800/80';
                      } else if (mark === 'A') {
                        cellLabel = 'অ';
                        cellStyle =
                          'bg-rose-100 text-rose-800 hover:bg-rose-200 dark:bg-rose-900/65 dark:text-rose-200 dark:hover:bg-rose-800/80';
                      } else if (mark === 'L') {
                        cellLabel = 'ছু';
                        cellStyle =
                          'bg-slate-200 text-slate-700 hover:bg-slate-300 dark:bg-slate-700 dark:text-slate-200 dark:hover:bg-slate-600';
                      }

                      return (
                        <td
                          key={d}
                          className="border-r border-slate-200 dark:border-slate-800 p-0 align-middle"
                        >
                          <button
                            type="button"
                            onClick={() => onTapCell(stu.id, d)}
                            aria-label={`রোল ${toBn(stu.roll)}, ${toBn(d)} তারিখ${
                              cellLabel ? `, বর্তমান ${cellLabel}` : ''
                            }`}
                            className={`w-full h-10 min-w-[38px] flex items-center justify-center font-bold text-xs sm:text-sm transition-colors ${cellStyle}`}
                          >
                            {cellLabel}
                          </button>
                        </td>
                      );
                    })}

                    <td className="border-r border-slate-200 dark:border-slate-800 px-2 py-1 text-center font-bold text-emerald-700 dark:text-emerald-300 tabular-nums">
                      {toBn(stats.pCount)}
                    </td>
                    <td className="border-r border-slate-200 dark:border-slate-800 px-2 py-1 text-center font-bold text-rose-700 dark:text-rose-300 tabular-nums">
                      {toBn(stats.aCount)}
                    </td>
                    <td className="px-2 py-1 text-center font-bold text-blue-700 dark:text-blue-300 tabular-nums">
                      {stats.rate}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>

          <tfoot>
            {/* Daily Present Row */}
            <tr className="bg-emerald-50 dark:bg-emerald-950/60 border-t-2 border-slate-300 dark:border-slate-700 font-semibold text-emerald-800 dark:text-emerald-200">
              <th
                scope="row"
                colSpan={2}
                className="sticky left-0 z-10 bg-[#ecfdf5] dark:bg-[#062c20] border-r border-b border-slate-200 dark:border-slate-800 px-2.5 py-2 text-left shadow-[2px_0_5px_-2px_rgba(0,0,0,0.12)]"
              >
                দৈনিক উপস্থিত
              </th>
              {days.map((d, idx) => (
                <td
                  key={d}
                  className={`border-r border-b border-slate-200 dark:border-slate-800 px-1 py-2 text-center tabular-nums ${
                    dayHolidays[idx]
                      ? 'bg-amber-100/90 dark:bg-amber-900/40 text-amber-900 dark:text-amber-200'
                      : ''
                  }`}
                >
                  {dayHolidays[idx] ? 'ছু' : toBn(dailyPresent[idx])}
                </td>
              ))}
              <td className="border-r border-b border-slate-200 dark:border-slate-800 px-2 py-2 text-center tabular-nums">
                {toBn(grandPresent)}
              </td>
              <td className="border-r border-b border-slate-200 dark:border-slate-800 px-2 py-2 text-center">
                —
              </td>
              <td className="border-b border-slate-200 dark:border-slate-800 px-2 py-2 text-center">
                —
              </td>
            </tr>

            {/* Daily Absent Row */}
            <tr className="bg-rose-50 dark:bg-rose-950/60 font-semibold text-rose-800 dark:text-rose-200">
              <th
                scope="row"
                colSpan={2}
                className="sticky left-0 z-10 bg-[#fff1f2] dark:bg-[#350d16] border-r border-b border-slate-200 dark:border-slate-800 px-2.5 py-2 text-left shadow-[2px_0_5px_-2px_rgba(0,0,0,0.12)]"
              >
                দৈনিক অনুপস্থিত
              </th>
              {days.map((d, idx) => (
                <td
                  key={d}
                  className={`border-r border-b border-slate-200 dark:border-slate-800 px-1 py-2 text-center tabular-nums ${
                    dayHolidays[idx]
                      ? 'bg-amber-100/90 dark:bg-amber-900/40 text-amber-900 dark:text-amber-200'
                      : ''
                  }`}
                >
                  {dayHolidays[idx] ? 'ছু' : toBn(dailyAbsent[idx])}
                </td>
              ))}
              <td className="border-r border-b border-slate-200 dark:border-slate-800 px-2 py-2 text-center">
                —
              </td>
              <td className="border-r border-b border-slate-200 dark:border-slate-800 px-2 py-2 text-center tabular-nums">
                {toBn(grandAbsent)}
              </td>
              <td className="border-b border-slate-200 dark:border-slate-800 px-2 py-2 text-center">
                —
              </td>
            </tr>

            {/* Daily Rate Row */}
            <tr className="bg-blue-50 dark:bg-blue-950/60 font-semibold text-blue-800 dark:text-blue-200">
              <th
                scope="row"
                colSpan={2}
                className="sticky left-0 z-10 bg-[#eff6ff] dark:bg-[#0d1c3d] border-r border-slate-200 dark:border-slate-800 px-2.5 py-2 text-left shadow-[2px_0_5px_-2px_rgba(0,0,0,0.12)]"
              >
                দৈনিক হার
              </th>
              {days.map((d, idx) => {
                if (dayHolidays[idx]) {
                  return (
                    <td
                      key={d}
                      className="border-r border-slate-200 dark:border-slate-800 px-1 py-2 text-center bg-amber-100/90 dark:bg-amber-900/40 text-amber-900 dark:text-amber-200"
                    >
                      ছু
                    </td>
                  );
                }
                const p = dailyPresent[idx];
                const a = dailyAbsent[idx];
                const sum = p + a;
                const rateStr = sum > 0 ? `${toBn(Math.round((p / sum) * 100))}%` : '—';
                return (
                  <td
                    key={d}
                    className="border-r border-slate-200 dark:border-slate-800 px-1 py-2 text-center tabular-nums text-[11px] sm:text-xs"
                  >
                    {rateStr}
                  </td>
                );
              })}
              <td className="border-r border-slate-200 dark:border-slate-800 px-2 py-2 text-center">
                —
              </td>
              <td className="border-r border-slate-200 dark:border-slate-800 px-2 py-2 text-center">
                —
              </td>
              <td className="px-2 py-2 text-center tabular-nums">{grandRate}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </section>
  );
}
