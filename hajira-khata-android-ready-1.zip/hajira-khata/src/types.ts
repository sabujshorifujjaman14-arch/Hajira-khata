export type Mark = 'P' | 'A' | 'L';

export interface Student {
  id: string;
  roll: number;
  name: string;
}

export interface MonthAttendance {
  marks: Record<string, Record<number, Mark>>;
  hol: Record<number, boolean>;
}

export interface HajiraState {
  schoolName: string;
  className: string;
  month: number; // 1 to 12
  year: number;
  students: Student[];
  attendance: Record<string, MonthAttendance>;
}

export type BackupMode = 'daily' | 'monthly' | 'all';
