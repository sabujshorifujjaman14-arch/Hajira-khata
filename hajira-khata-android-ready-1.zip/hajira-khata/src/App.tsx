import {useCallback, useEffect, useMemo, useState} from 'react';
import {AddStudentForm} from './components/AddStudentForm';
import {AttendanceTable} from './components/AttendanceTable';
import {BackupCard} from './components/BackupCard';
import {BrushToolbar} from './components/BrushToolbar';
import {DayBottomSheet} from './components/DayBottomSheet';
import {FieldsCard} from './components/FieldsCard';
import {HeroHeader} from './components/HeroHeader';
import {PrintPreview} from './components/PrintPreview';
import {StatsCards} from './components/StatsCards';
import {HajiraState, Mark, MonthAttendance} from './types';
import {getMonthKey, isHoliday} from './utils/bengali';
import {saveAndShareFile} from './utils/capacitorBridge';
import {exportMonthToXlsxBytes, getExcelFilename} from './utils/excel';
import {
  loadState,
  recoverFromIndexedDbIfEmpty,
  saveState,
} from './utils/storage';

export default function App() {
  const [state, setState] = useState<HajiraState>(() => loadState());
  const [brush, setBrush] = useState<Mark>('P');
  const [deleteMode, setDeleteMode] = useState(false);
  const [activeDaySheet, setActiveDaySheet] = useState<number | null>(null);
  const [printOpen, setPrintOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const updateState = useCallback((updater: (prev: HajiraState) => HajiraState) => {
    setState((prev) => {
      const next = updater(prev);
      saveState(next);
      return next;
    });
  }, []);

  useEffect(() => {
    let mounted = true;
    recoverFromIndexedDbIfEmpty().then((recovered) => {
      if (mounted && recovered) {
        setState(recovered);
      }
    });
    return () => {
      mounted = false;
    };
  }, []);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    window.setTimeout(() => {
      setToastMsg((curr) => (curr === msg ? null : curr));
    }, 3000);
  }, []);

  const monthKey = getMonthKey(state.year, state.month);
  const monthData: MonthAttendance = useMemo(
    () => state.attendance[monthKey] ?? {marks: {}, hol: {}},
    [state.attendance, monthKey],
  );

  const handleTapCell = useCallback(
    (studentId: string, day: number) => {
      updateState((prev) => {
        const mKey = getMonthKey(prev.year, prev.month);
        const currMonth = prev.attendance[mKey] ?? {marks: {}, hol: {}};
        if (isHoliday(prev.year, prev.month, day, currMonth.hol)) {
          return prev;
        }
        const currStuMarks = currMonth.marks[studentId] ?? {};
        const existing = currStuMarks[day];
        const nextStuMarks = {...currStuMarks};

        if (existing === brush) {
          delete nextStuMarks[day];
        } else {
          nextStuMarks[day] = brush;
        }

        const nextMarks = {...currMonth.marks};
        if (Object.keys(nextStuMarks).length > 0) {
          nextMarks[studentId] = nextStuMarks;
        } else {
          delete nextMarks[studentId];
        }

        return {
          ...prev,
          attendance: {
            ...prev.attendance,
            [mKey]: {
              ...currMonth,
              marks: nextMarks,
            },
          },
        };
      });
    },
    [brush, updateState],
  );

  const handleMarkAllPresent = useCallback(
    (day: number) => {
      updateState((prev) => {
        const mKey = getMonthKey(prev.year, prev.month);
        const currMonth = prev.attendance[mKey] ?? {marks: {}, hol: {}};
        const nextHol = {...currMonth.hol};
        if (isHoliday(prev.year, prev.month, day, currMonth.hol)) {
          nextHol[day] = false;
        }

        const nextMarks = {...currMonth.marks};
        for (const stu of prev.students) {
          nextMarks[stu.id] = {
            ...(nextMarks[stu.id] ?? {}),
            [day]: 'P',
          };
        }

        return {
          ...prev,
          attendance: {
            ...prev.attendance,
            [mKey]: {
              marks: nextMarks,
              hol: nextHol,
            },
          },
        };
      });
    },
    [updateState],
  );

  const handleToggleHoliday = useCallback(
    (day: number) => {
      updateState((prev) => {
        const mKey = getMonthKey(prev.year, prev.month);
        const currMonth = prev.attendance[mKey] ?? {marks: {}, hol: {}};
        const currentlyHol = isHoliday(prev.year, prev.month, day, currMonth.hol);
        return {
          ...prev,
          attendance: {
            ...prev.attendance,
            [mKey]: {
              ...currMonth,
              hol: {
                ...currMonth.hol,
                [day]: !currentlyHol,
              },
            },
          },
        };
      });
    },
    [updateState],
  );

  const handleClearDayMarks = useCallback(
    (day: number) => {
      updateState((prev) => {
        const mKey = getMonthKey(prev.year, prev.month);
        const currMonth = prev.attendance[mKey] ?? {marks: {}, hol: {}};
        const nextMarks: Record<string, Record<number, Mark>> = {};

        for (const [stuId, dayMap] of Object.entries(currMonth.marks)) {
          const copy = {...dayMap};
          delete copy[day];
          if (Object.keys(copy).length > 0) {
            nextMarks[stuId] = copy;
          }
        }

        return {
          ...prev,
          attendance: {
            ...prev.attendance,
            [mKey]: {
              ...currMonth,
              marks: nextMarks,
            },
          },
        };
      });
    },
    [updateState],
  );

  const handleUpdateStudentRoll = useCallback(
    (studentId: string, roll: number) => {
      updateState((prev) => ({
        ...prev,
        students: prev.students.map((s) =>
          s.id === studentId ? {...s, roll} : s,
        ),
      }));
    },
    [updateState],
  );

  const handleUpdateStudentName = useCallback(
    (studentId: string, name: string) => {
      updateState((prev) => ({
        ...prev,
        students: prev.students.map((s) =>
          s.id === studentId ? {...s, name} : s,
        ),
      }));
    },
    [updateState],
  );

  const handleDeleteStudent = useCallback(
    (studentId: string) => {
      updateState((prev) => ({
        ...prev,
        students: prev.students.filter((s) => s.id !== studentId),
      }));
    },
    [updateState],
  );

  const handleAddStudent = useCallback(
    (roll: number, name: string) => {
      updateState((prev) => ({
        ...prev,
        students: [
          ...prev.students,
          {
            id: `s-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            roll,
            name,
          },
        ],
      }));
    },
    [updateState],
  );

  const handleDownloadExcel = useCallback(async () => {
    const bytes = exportMonthToXlsxBytes(state);
    const filename = getExcelFilename(state.year, state.month);
    const res = await saveAndShareFile({
      filename,
      mimeType:
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      data: bytes,
    });
    if (res.ok) {
      showToast(`${filename} ডাউনলোড হয়েছে।`);
    } else {
      showToast(res.error || 'Excel ডাউনলোড করা যায়নি।');
    }
  }, [state, showToast]);

  const handleRestoreState = useCallback(
    (nextState: HajiraState) => {
      updateState(() => nextState);
    },
    [updateState],
  );

  const suggestedRoll =
    state.students.length > 0
      ? state.students[state.students.length - 1].roll + 1
      : 1;

  const activeDayIsHoliday =
    activeDaySheet !== null
      ? isHoliday(state.year, state.month, activeDaySheet, monthData.hol)
      : false;

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-x-hidden pb-10">
      <HeroHeader
        schoolName={state.schoolName}
        className={state.className}
        month={state.month}
        year={state.year}
      />

      <main className="max-w-7xl mx-auto px-3 sm:px-6 pt-3.5 sm:pt-5 space-y-3.5 sm:space-y-4">
        <FieldsCard
          schoolName={state.schoolName}
          className={state.className}
          month={state.month}
          year={state.year}
          onChangeSchoolName={(schoolName) =>
            updateState((prev) => ({...prev, schoolName}))
          }
          onChangeClassName={(className) =>
            updateState((prev) => ({...prev, className}))
          }
          onChangeMonthYear={(month, year) => {
            setActiveDaySheet(null);
            updateState((prev) => ({...prev, month, year}));
          }}
        />

        <BrushToolbar
          brush={brush}
          deleteMode={deleteMode}
          onSelectBrush={setBrush}
          onDownloadExcel={handleDownloadExcel}
          onOpenPrintPreview={() => setPrintOpen(true)}
          onToggleDeleteMode={() => setDeleteMode((d) => !d)}
        />

        <AttendanceTable
          year={state.year}
          month={state.month}
          students={state.students}
          monthData={monthData}
          deleteMode={deleteMode}
          onTapCell={handleTapCell}
          onOpenDaySheet={setActiveDaySheet}
          onUpdateStudentRoll={handleUpdateStudentRoll}
          onUpdateStudentName={handleUpdateStudentName}
          onDeleteStudent={handleDeleteStudent}
        />

        <AddStudentForm
          suggestedRoll={suggestedRoll}
          onAddStudent={handleAddStudent}
        />

        <StatsCards
          year={state.year}
          month={state.month}
          students={state.students}
          monthData={monthData}
        />

        <BackupCard state={state} onRestoreState={handleRestoreState} />
      </main>

      <DayBottomSheet
        day={activeDaySheet}
        month={state.month}
        year={state.year}
        isDayHoliday={activeDayIsHoliday}
        onMarkAllPresent={handleMarkAllPresent}
        onToggleHoliday={handleToggleHoliday}
        onClearDayMarks={handleClearDayMarks}
        onClose={() => setActiveDaySheet(null)}
      />

      <PrintPreview
        open={printOpen}
        state={state}
        onClose={() => setPrintOpen(false)}
        onDownloadExcel={handleDownloadExcel}
      />

      {toastMsg && (
        <div
          role="status"
          className="no-print fixed bottom-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 text-sm font-semibold shadow-lg max-w-[90vw] text-center"
        >
          {toastMsg}
        </div>
      )}
    </div>
  );
}
