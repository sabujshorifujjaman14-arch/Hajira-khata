import * as XLSX from 'xlsx';
import {HajiraState, Mark, MonthAttendance, Student} from '../types';
import {
  BN_MONTHS,
  BN_WEEKDAYS_SHORT,
  getDaysInMonth,
  getMonthKey,
  getWeekdayIndex,
  isFriday,
  isHoliday,
  parseBnOrEnInt,
  parseMonthName,
  toBn,
} from './bengali';

export function buildExcelWorkbook(state: HajiraState): XLSX.WorkBook {
  const {schoolName, className, month, year, students, attendance} = state;
  const monthKey = getMonthKey(year, month);
  const monthData: MonthAttendance = attendance[monthKey] ?? {marks: {}, hol: {}};
  const daysInMonth = getDaysInMonth(year, month);

  const rows: (string | number)[][] = [];

  // Row 1: school name
  rows.push([schoolName.trim() || 'হাজিরা খাতা']);

  // Row 2: "শ্রেণি: X", blank, "মাস: মাসের নাম সাল"
  rows.push([
    `শ্রেণি: ${className.trim() || 'সপ্তম'}`,
    '',
    `মাস: ${BN_MONTHS[month - 1]} ${toBn(year)}`,
  ]);

  // Row 3: blank row
  rows.push([]);

  // Row 4: header row "রোল", "নাম", 1..N, "উপস্থিত", "অনুপস্থিত", "হার (%)"
  const headerRow: string[] = ['রোল', 'নাম'];
  for (let d = 1; d <= daysInMonth; d += 1) {
    headerRow.push(toBn(d));
  }
  headerRow.push('উপস্থিত', 'অনুপস্থিত', 'হার (%)');
  rows.push(headerRow);

  // Row 5: weekday-letter row
  const weekdayRow: string[] = ['', ''];
  for (let d = 1; d <= daysInMonth; d += 1) {
    weekdayRow.push(BN_WEEKDAYS_SHORT[getWeekdayIndex(year, month, d)]);
  }
  weekdayRow.push('', '', '');
  rows.push(weekdayRow);

  const dailyPresent = new Array<number>(daysInMonth + 1).fill(0);
  const dailyAbsent = new Array<number>(daysInMonth + 1).fill(0);

  // Student rows
  for (const stu of students) {
    const row: string[] = [toBn(stu.roll), stu.name];
    let pCount = 0;
    let aCount = 0;
    const stuMarks = monthData.marks[stu.id] ?? {};

    for (let d = 1; d <= daysInMonth; d += 1) {
      if (isHoliday(year, month, d, monthData.hol)) {
        row.push('ছু');
      } else {
        const m = stuMarks[d];
        if (m === 'P') {
          row.push('উ');
          pCount += 1;
          dailyPresent[d] += 1;
        } else if (m === 'A') {
          row.push('অ');
          aCount += 1;
          dailyAbsent[d] += 1;
        } else if (m === 'L') {
          row.push('ছু');
        } else {
          row.push('');
        }
      }
    }

    const totalPA = pCount + aCount;
    const rate = totalPA > 0 ? `${toBn(Math.round((pCount / totalPA) * 100))}%` : '—';
    row.push(toBn(pCount), toBn(aCount), rate);
    rows.push(row);
  }

  // Daily summary rows
  const totalPresentRow: string[] = ['দৈনিক উপস্থিত', ''];
  const totalAbsentRow: string[] = ['দৈনিক অনুপস্থিত', ''];
  const totalRateRow: string[] = ['হার (%)', ''];

  let grandPresent = 0;
  let grandAbsent = 0;

  for (let d = 1; d <= daysInMonth; d += 1) {
    if (isHoliday(year, month, d, monthData.hol)) {
      totalPresentRow.push('ছু');
      totalAbsentRow.push('ছু');
      totalRateRow.push('ছু');
    } else {
      const p = dailyPresent[d];
      const a = dailyAbsent[d];
      grandPresent += p;
      grandAbsent += a;
      totalPresentRow.push(toBn(p));
      totalAbsentRow.push(toBn(a));
      const sum = p + a;
      totalRateRow.push(sum > 0 ? `${toBn(Math.round((p / sum) * 100))}%` : '—');
    }
  }

  const grandSum = grandPresent + grandAbsent;
  const grandRate = grandSum > 0 ? `${toBn(Math.round((grandPresent / grandSum) * 100))}%` : '—';

  totalPresentRow.push(toBn(grandPresent), '', '');
  totalAbsentRow.push('', toBn(grandAbsent), '');
  totalRateRow.push('', '', grandRate);

  rows.push(totalPresentRow);
  rows.push(totalAbsentRow);
  rows.push(totalRateRow);

  const worksheet = XLSX.utils.aoa_to_sheet(rows);
  worksheet['!cols'] = [
    {wch: 8},
    {wch: 24},
    ...Array.from({length: daysInMonth}, () => ({wch: 4.5})),
    {wch: 9},
    {wch: 11},
    {wch: 9},
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'হাজিরা খাতা');
  return workbook;
}

export function exportMonthToXlsxBytes(state: HajiraState): Uint8Array {
  const wb = buildExcelWorkbook(state);
  const out = XLSX.write(wb, {bookType: 'xlsx', type: 'array'});
  return new Uint8Array(out as ArrayBuffer);
}

export function getExcelFilename(year: number, month1to12: number): string {
  return `hajira-${year}-${String(month1to12).padStart(2, '0')}.xlsx`;
}

export function restoreFromExcelBuffer(
  buffer: ArrayBuffer,
  currentState: HajiraState,
): {ok: true; nextState: HajiraState; message: string} | {ok: false; error: string} {
  try {
    const wb = XLSX.read(buffer, {type: 'array'});
    const firstSheetName = wb.SheetNames[0];
    if (!firstSheetName) {
      return {ok: false, error: 'Excel ফাইলে কোনো শীট পাওয়া যায়নি।'};
    }
    const ws = wb.Sheets[firstSheetName];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(ws, {header: 1, defval: ''});
    if (rows.length < 5) {
      return {ok: false, error: 'এই Excel ফাইলটি হাজিরা খাতার ফরম্যাটে নেই।'};
    }

    // Row 1: school name
    const rawSchool = String(rows[0]?.[0] ?? '').trim();
    const restoredSchoolName = rawSchool === 'হাজিরা খাতা' ? '' : rawSchool;

    // Row 2: class & month/year
    const row2 = rows[1] ?? [];
    let restoredClassName = currentState.className;
    let restoredMonth: number | null = null;
    let restoredYear: number | null = null;

    for (const cell of row2) {
      const text = String(cell ?? '').trim();
      if (!text) continue;
      if (text.startsWith('শ্রেণি:') || text.startsWith('শ্রেণি :')) {
        restoredClassName = text.replace(/^শ্রেণি\s*:\s*/, '').trim();
      } else if (text.startsWith('মাস:') || text.startsWith('মাস :')) {
        const afterColon = text.replace(/^মাস\s*:\s*/, '').trim();
        const parts = afterColon.split(/\s+/);
        for (const part of parts) {
          const m = parseMonthName(part);
          if (m !== null) {
            restoredMonth = m;
          }
          const y = parseBnOrEnInt(part);
          if (y !== null && y >= 1900 && y <= 2200) {
            restoredYear = y;
          }
        }
      }
    }

    if (restoredMonth === null || restoredYear === null) {
      return {ok: false, error: 'Excel ফাইলে মাস এবং সাল সঠিকভাবে পাওয়া যায়নি।'};
    }

    // Find header row containing "রোল" and "নাম"
    const headerRowIndex = rows.findIndex((r) => {
      const c0 = String(r?.[0] ?? '').trim();
      const c1 = String(r?.[1] ?? '').trim();
      return c0 === 'রোল' && c1 === 'নাম';
    });

    if (headerRowIndex < 0) {
      return {ok: false, error: 'Excel ফাইলে "রোল" ও "নাম" শিরোনাম সারি পাওয়া যায়নি।'};
    }

    const headerRow = rows[headerRowIndex];
    const dayColMap = new Map<number, number>(); // colIndex -> day (1..31)
    for (let c = 2; c < headerRow.length; c += 1) {
      const cellText = String(headerRow[c] ?? '').trim();
      if (cellText === 'উপস্থিত' || cellText === 'অনুপস্থিত' || cellText === 'হার (%)') {
        break;
      }
      const d = parseBnOrEnInt(cellText);
      if (d !== null && d >= 1 && d <= 31) {
        dayColMap.set(c, d);
      }
    }

    if (dayColMap.size === 0) {
      return {ok: false, error: 'Excel ফাইলে দিনের কলাম পাওয়া যায়নি।'};
    }

    // Check if next row is weekday-letter row
    let dataStartIndex = headerRowIndex + 1;
    const maybeWeekdayRow = rows[dataStartIndex];
    if (
      maybeWeekdayRow &&
      String(maybeWeekdayRow[0] ?? '').trim() === '' &&
      String(maybeWeekdayRow[1] ?? '').trim() === ''
    ) {
      dataStartIndex += 1;
    }

    // Parse student rows & locate footer "দৈনিক উপস্থিত" row
    const parsedStudents: {roll: number; name: string; dayCells: Record<number, string>}[] = [];
    let dailyPresentRow: unknown[] | null = null;

    for (let r = dataStartIndex; r < rows.length; r += 1) {
      const row = rows[r] ?? [];
      const col0 = String(row[0] ?? '').trim();
      if (col0 === 'দৈনিক উপস্থিত') {
        dailyPresentRow = row;
        break;
      }
      if (col0 === 'দৈনিক অনুপস্থিত' || col0 === 'দৈনিক হার' || col0 === 'হার (%)') {
        continue;
      }
      const roll = parseBnOrEnInt(col0);
      if (roll === null || roll <= 0) {
        continue;
      }
      const name = String(row[1] ?? '').trim();
      const dayCells: Record<number, string> = {};
      for (const [colIdx, day] of dayColMap.entries()) {
        dayCells[day] = String(row[colIdx] ?? '').trim();
      }
      parsedStudents.push({roll, name, dayCells});
    }

    // Match students by roll (preserve IDs so other months remain untouched)
    const nextStudents: Student[] = currentState.students.map((s) => ({...s}));
    const rollToStudent = new Map<number, Student>();
    for (const s of nextStudents) {
      if (!rollToStudent.has(s.roll)) {
        rollToStudent.set(s.roll, s);
      }
    }

    let idSeq = Date.now();
    const matchedStudents: {student: Student; dayCells: Record<number, string>}[] = [];

    for (const parsed of parsedStudents) {
      let existing = rollToStudent.get(parsed.roll);
      if (existing) {
        existing.name = parsed.name;
      } else {
        existing = {
          id: `s-${idSeq++}`,
          roll: parsed.roll,
          name: parsed.name,
        };
        nextStudents.push(existing);
        rollToStudent.set(parsed.roll, existing);
      }
      matchedStudents.push({student: existing, dayCells: parsed.dayCells});
    }

    // Determine holidays per day for the restored month
    const daysInRestoredMonth = getDaysInMonth(restoredYear, restoredMonth);
    const restoredHol: Record<number, boolean> = {};

    for (let d = 1; d <= daysInRestoredMonth; d += 1) {
      const colEntry = Array.from(dayColMap.entries()).find(([, dayVal]) => dayVal === d);
      const colIdx = colEntry?.[0];
      const friday = isFriday(restoredYear, restoredMonth, d);

      let isDayHol: boolean;
      if (dailyPresentRow && colIdx !== undefined) {
        const footerVal = String(dailyPresentRow[colIdx] ?? '').trim();
        if (footerVal === 'ছু') {
          isDayHol = true;
        } else if (parseBnOrEnInt(footerVal) !== null) {
          isDayHol = false;
        } else {
          // Fallback inspection
          const vals = matchedStudents.map((m) => m.dayCells[d] ?? '');
          const allLeave = vals.length > 0 && vals.every((v) => v === 'ছু');
          isDayHol = allLeave && friday;
        }
      } else {
        const vals = matchedStudents.map((m) => m.dayCells[d] ?? '');
        const hasPA = vals.some((v) => v === 'উ' || v === 'অ');
        const hasBlank = vals.some((v) => v === '');
        const allLeave = vals.length > 0 && vals.every((v) => v === 'ছু');
        if (hasPA || hasBlank) {
          isDayHol = false;
        } else if (allLeave) {
          isDayHol = true;
        } else {
          isDayHol = friday;
        }
      }

      if (isDayHol && !friday) {
        restoredHol[d] = true;
      } else if (!isDayHol && friday) {
        restoredHol[d] = false;
      }
    }

    // Build marks for the restored month only
    const restoredMarks: Record<string, Record<number, Mark>> = {};
    for (const {student, dayCells} of matchedStudents) {
      const stuMarks: Record<number, Mark> = {};
      for (let d = 1; d <= daysInRestoredMonth; d += 1) {
        if (isHoliday(restoredYear, restoredMonth, d, restoredHol)) {
          continue;
        }
        const cell = dayCells[d] ?? '';
        if (cell === 'উ' || cell.toUpperCase() === 'P') {
          stuMarks[d] = 'P';
        } else if (cell === 'অ' || cell.toUpperCase() === 'A') {
          stuMarks[d] = 'A';
        } else if (cell === 'ছু' || cell.toUpperCase() === 'L') {
          stuMarks[d] = 'L';
        }
      }
      if (Object.keys(stuMarks).length > 0) {
        restoredMarks[student.id] = stuMarks;
      }
    }

    const restoredMonthKey = getMonthKey(restoredYear, restoredMonth);
    const nextState: HajiraState = {
      ...currentState,
      schoolName: restoredSchoolName,
      className: restoredClassName || currentState.className,
      month: restoredMonth,
      year: restoredYear,
      students: nextStudents,
      attendance: {
        ...currentState.attendance,
        [restoredMonthKey]: {
          marks: restoredMarks,
          hol: restoredHol,
        },
      },
    };

    return {
      ok: true,
      nextState,
      message: `${BN_MONTHS[restoredMonth - 1]} ${toBn(restoredYear)} মাসের হাজিরা সফলভাবে ফিরিয়ে আনা হয়েছে (অন্যান্য মাস অপরিবর্তিত রয়েছে)।`,
    };
  } catch {
    return {
      ok: false,
      error: 'Excel ফাইলটি পড়া যায়নি। অনুগ্রহ করে এই অ্যাপ থেকে ডাউনলোড করা সঠিক .xlsx ফাইল নির্বাচন করুন।',
    };
  }
}
