import {HajiraState, Mark, MonthAttendance, Student} from '../types';
import {
  BN_MONTHS,
  BN_WEEKDAYS_FULL,
  BN_WEEKDAYS_SHORT,
  getDaysInMonth,
  getMonthKey,
  getWeekdayIndex,
  isFriday,
  isHoliday,
  parseBnOrEnInt,
  parseMonthName,
  toBn,
} from './bengali';
import {sanitizeState} from './storage';

export function generateDailyBackupText(state: HajiraState, day: number): string {
  const {schoolName, className, month, year, students, attendance} = state;
  const monthKey = getMonthKey(year, month);
  const monthData: MonthAttendance = attendance[monthKey] ?? {marks: {}, hol: {}};
  const weekdayName = BN_WEEKDAYS_FULL[getWeekdayIndex(year, month, day)];
  const dayHoliday = isHoliday(year, month, day, monthData.hol);

  const lines: string[] = [];
  lines.push(schoolName.trim() || 'স্কুলের নাম');
  lines.push(`শ্রেণি: ${className.trim() || 'সপ্তম'}`);
  lines.push(
    `তারিখ: ${toBn(day)} ${BN_MONTHS[month - 1]} ${toBn(year)}, ${weekdayName}${dayHoliday ? ' (ছুটি)' : ''}`,
  );
  lines.push('------------------------------');

  let present = 0;
  let absent = 0;
  let leave = 0;

  for (const stu of students) {
    const stuName = stu.name.trim() || '(নাম নেই)';
    let statusText = 'হাজিরা নেই';

    if (dayHoliday) {
      statusText = 'ছুটি';
      leave += 1;
    } else {
      const m = monthData.marks[stu.id]?.[day];
      if (m === 'P') {
        statusText = 'উপস্থিত';
        present += 1;
      } else if (m === 'A') {
        statusText = 'অনুপস্থিত';
        absent += 1;
      } else if (m === 'L') {
        statusText = 'ছুটি';
        leave += 1;
      }
    }

    lines.push(`${toBn(stu.roll)}. ${stuName} — ${statusText}`);
  }

  lines.push('------------------------------');
  const totalPA = present + absent;
  const rate = totalPA > 0 ? `${toBn(Math.round((present / totalPA) * 100))}%` : '—';
  lines.push(`মোট উপস্থিত: ${toBn(present)} জন`);
  lines.push(`মোট অনুপস্থিত: ${toBn(absent)} জন`);
  lines.push(`ছুটি: ${toBn(leave)} জন`);
  lines.push(`উপস্থিতির হার: ${rate}`);

  return lines.join('\n');
}

export function generateMonthlyBackupText(state: HajiraState): string {
  const {month, year, students, attendance} = state;
  const monthKey = getMonthKey(year, month);
  const monthData: MonthAttendance = attendance[monthKey] ?? {marks: {}, hol: {}};
  const daysInMonth = getDaysInMonth(year, month);

  const lines: string[] = [];

  const headerCols = ['রোল', 'নাম'];
  const weekdayCols = ['', 'বার'];
  for (let d = 1; d <= daysInMonth; d += 1) {
    headerCols.push(toBn(d));
    weekdayCols.push(BN_WEEKDAYS_SHORT[getWeekdayIndex(year, month, d)]);
  }
  headerCols.push('উপস্থিত', 'অনুপস্থিত', 'হার');
  weekdayCols.push('', '', '');

  lines.push(headerCols.join('\t'));
  lines.push(weekdayCols.join('\t'));

  const dailyP = new Array<number>(daysInMonth + 1).fill(0);
  const dailyA = new Array<number>(daysInMonth + 1).fill(0);

  for (const stu of students) {
    const cols: string[] = [toBn(stu.roll), stu.name];
    let p = 0;
    let a = 0;
    const stuMarks = monthData.marks[stu.id] ?? {};

    for (let d = 1; d <= daysInMonth; d += 1) {
      if (isHoliday(year, month, d, monthData.hol)) {
        cols.push('ছু');
      } else {
        const m = stuMarks[d];
        if (m === 'P') {
          cols.push('উ');
          p += 1;
          dailyP[d] += 1;
        } else if (m === 'A') {
          cols.push('অ');
          a += 1;
          dailyA[d] += 1;
        } else if (m === 'L') {
          cols.push('ছু');
        } else {
          cols.push('');
        }
      }
    }

    const totalPA = p + a;
    const rate = totalPA > 0 ? `${toBn(Math.round((p / totalPA) * 100))}%` : '—';
    cols.push(toBn(p), toBn(a), rate);
    lines.push(cols.join('\t'));
  }

  const pRow: string[] = ['দৈনিক উপস্থিত', ''];
  const aRow: string[] = ['দৈনিক অনুপস্থিত', ''];
  const rRow: string[] = ['দৈনিক হার', ''];
  let grandP = 0;
  let grandA = 0;

  for (let d = 1; d <= daysInMonth; d += 1) {
    if (isHoliday(year, month, d, monthData.hol)) {
      pRow.push('ছু');
      aRow.push('ছু');
      rRow.push('ছু');
    } else {
      const p = dailyP[d];
      const a = dailyA[d];
      grandP += p;
      grandA += a;
      pRow.push(toBn(p));
      aRow.push(toBn(a));
      const sum = p + a;
      rRow.push(sum > 0 ? `${toBn(Math.round((p / sum) * 100))}%` : '—');
    }
  }

  const grandSum = grandP + grandA;
  const grandRate = grandSum > 0 ? `${toBn(Math.round((grandP / grandSum) * 100))}%` : '—';
  pRow.push(toBn(grandP), '', '');
  aRow.push('', toBn(grandA), '');
  rRow.push('', '', grandRate);

  lines.push(pRow.join('\t'));
  lines.push(aRow.join('\t'));
  lines.push(rRow.join('\t'));

  return lines.join('\n');
}

export function generateAllMonthsBackupJson(state: HajiraState): string {
  return JSON.stringify(state, null, 2);
}

export type TextRestoreAnalysis =
  | {kind: 'json'; state: HajiraState}
  | {kind: 'daily-txt'; nextState: HajiraState; message: string}
  | {kind: 'error'; error: string};

export function analyzeTextBackup(text: string, currentState: HajiraState): TextRestoreAnalysis {
  const trimmed = text.trim();
  if (!trimmed) {
    return {kind: 'error', error: 'ফিরিয়ে আনার জন্য কোনো লেখা বা ফাইল নির্বাচন করা হয়নি।'};
  }

  // Try JSON full state
  if (trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed);
      if (
        !parsed ||
        typeof parsed !== 'object' ||
        !Array.isArray((parsed as Record<string, unknown>).students) ||
        typeof (parsed as Record<string, unknown>).attendance !== 'object'
      ) {
        return {
          kind: 'error',
          error: 'JSON ফাইলটি হাজিরা খাতার সম্পূর্ণ ব্যাকআপ ফরম্যাটে নেই।',
        };
      }
      const sanitized = sanitizeState(parsed);
      if (!sanitized) {
        return {
          kind: 'error',
          error: 'JSON ব্যাকআপের তথ্য সঠিক নয়।',
        };
      }
      return {kind: 'json', state: sanitized};
    } catch {
      return {
        kind: 'error',
        error: 'JSON লেখাটি সঠিক নয়। অনুগ্রহ করে সম্পূর্ণ ব্যাকআপ পেস্ট করুন।',
      };
    }
  }

  // Try Daily .txt format
  const lines = trimmed.split(/\r?\n/).map((l) => l.trim());
  const dateLine = lines.find((l) => l.startsWith('তারিখ:'));
  if (dateLine) {
    const afterDate = dateLine.replace(/^তারিখ:\s*/, '');
    const tokens = afterDate.split(/[\s,]+/);
    const dayVal = parseBnOrEnInt(tokens[0]);
    let monthVal: number | null = null;
    let yearVal: number | null = null;
    for (const t of tokens) {
      const m = parseMonthName(t);
      if (m !== null) monthVal = m;
      const y = parseBnOrEnInt(t);
      if (y !== null && y >= 1900 && y <= 2200) yearVal = y;
    }

    if (dayVal && monthVal && yearVal) {
      const daysInTarget = getDaysInMonth(yearVal, monthVal);
      if (dayVal >= 1 && dayVal <= daysInTarget) {
        const classLine = lines.find((l) => l.startsWith('শ্রেণি:'));
        const restoredSchool =
          lines[0] && !lines[0].startsWith('শ্রেণি:') && lines[0] !== 'স্কুলের নাম'
            ? lines[0]
            : currentState.schoolName;
        const restoredClass = classLine
          ? classLine.replace(/^শ্রেণি:\s*/, '').trim()
          : currentState.className;

        const nextStudents: Student[] = currentState.students.map((s) => ({...s}));
        const rollMap = new Map<number, Student>();
        for (const s of nextStudents) {
          if (!rollMap.has(s.roll)) rollMap.set(s.roll, s);
        }

        const monthKey = getMonthKey(yearVal, monthVal);
        const existingMonth: MonthAttendance = currentState.attendance[monthKey] ?? {
          marks: {},
          hol: {},
        };
        const nextMarks: Record<string, Record<number, Mark>> = {
          ...existingMonth.marks,
        };
        const nextHol: Record<number, boolean> = {...existingMonth.hol};

        const isDailyHoliday = dateLine.includes('(ছুটি)');
        const friday = isFriday(yearVal, monthVal, dayVal);
        if (isDailyHoliday && !friday) nextHol[dayVal] = true;
        else if (!isDailyHoliday && friday) nextHol[dayVal] = false;

        let idSeq = Date.now();
        let matchedCount = 0;

        for (const line of lines) {
          const match = line.match(/^([০-৯\d]+)\.\s*(.*?)\s*[—-]\s*(উপস্থিত|অনুপস্থিত|ছুটি|হাজিরা নেই)$/);
          if (!match) continue;
          const roll = parseBnOrEnInt(match[1]);
          if (roll === null || roll <= 0) continue;
          const rawName = match[2] === '(নাম নেই)' ? '' : match[2].trim();
          const status = match[3];

          let stu = rollMap.get(roll);
          if (stu) {
            if (rawName) stu.name = rawName;
          } else {
            stu = {id: `s-${idSeq++}`, roll, name: rawName};
            nextStudents.push(stu);
            rollMap.set(roll, stu);
          }

          const stuDayMarks = {...(nextMarks[stu.id] ?? {})};
          if (!isDailyHoliday) {
            if (status === 'উপস্থিত') stuDayMarks[dayVal] = 'P';
            else if (status === 'অনুপস্থিত') stuDayMarks[dayVal] = 'A';
            else if (status === 'ছুটি') stuDayMarks[dayVal] = 'L';
            else delete stuDayMarks[dayVal];
          }
          if (Object.keys(stuDayMarks).length > 0) {
            nextMarks[stu.id] = stuDayMarks;
          } else {
            delete nextMarks[stu.id];
          }
          matchedCount += 1;
        }

        if (matchedCount > 0) {
          return {
            kind: 'daily-txt',
            nextState: {
              ...currentState,
              schoolName: restoredSchool,
              className: restoredClass,
              month: monthVal,
              year: yearVal,
              students: nextStudents,
              attendance: {
                ...currentState.attendance,
                [monthKey]: {marks: nextMarks, hol: nextHol},
              },
            },
            message: `${toBn(dayVal)} ${BN_MONTHS[monthVal - 1]} ${toBn(yearVal)} তারিখের দৈনিক হাজিরা ফিরিয়ে আনা হয়েছে।`,
          };
        }
      }
    }
  }

  return {
    kind: 'error',
    error: 'ব্যাকআপের ফরম্যাট চেনা যায়নি। এই অ্যাপ থেকে তৈরি .xlsx, .json অথবা দৈনিক .txt ব্যাকআপ ব্যবহার করুন।',
  };
}
