const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'] as const;

export const BN_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
] as const;

export const BN_WEEKDAYS_SHORT = ['র', 'সো', 'ম', 'বু', 'বৃ', 'শু', 'শ'] as const;

export const BN_WEEKDAYS_FULL = [
  'রবিবার',
  'সোমবার',
  'মঙ্গলবার',
  'বুধবার',
  'বৃহস্পতিবার',
  'শুক্রবার',
  'শনিবার',
] as const;

export function toBn(value: number | string): string {
  return String(value).replace(/\d/g, (digit) => BN_DIGITS[Number(digit)] ?? digit);
}

export function toEnDigits(value: string): string {
  return value.replace(/[০-৯]/g, (ch) => {
    const idx = BN_DIGITS.indexOf(ch as (typeof BN_DIGITS)[number]);
    return idx >= 0 ? String(idx) : ch;
  });
}

export function parseBnOrEnInt(value: unknown): number | null {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? Math.trunc(value) : null;
  }
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = toEnDigits(value).trim();
  if (!/^-?\d+$/.test(normalized)) {
    return null;
  }
  const parsed = Number.parseInt(normalized, 10);
  return Number.isFinite(parsed) ? parsed : null;
}

export function getDaysInMonth(year: number, month1to12: number): number {
  return new Date(year, month1to12, 0).getDate();
}

export function getMonthKey(year: number, month1to12: number): string {
  return `${year}-${String(month1to12).padStart(2, '0')}`;
}

export function getWeekdayIndex(year: number, month1to12: number, day: number): number {
  return new Date(year, month1to12 - 1, day).getDay();
}

export function isFriday(year: number, month1to12: number, day: number): boolean {
  return getWeekdayIndex(year, month1to12, day) === 5;
}

export function isHoliday(
  year: number,
  month1to12: number,
  day: number,
  holMap?: Record<number, boolean>,
): boolean {
  if (holMap && typeof holMap[day] === 'boolean') {
    return holMap[day];
  }
  return isFriday(year, month1to12, day);
}

export function parseMonthName(input: string): number | null {
  const cleaned = input.trim();
  const exactIdx = BN_MONTHS.findIndex((m) => m === cleaned);
  if (exactIdx >= 0) {
    return exactIdx + 1;
  }
  const aliases: Record<string, number> = {
    'জানুয়ারী': 1,
    'ফেব্রুয়ারী': 2,
    'আগষ্ট': 8,
    'ডিসেম্বর': 12,
  };
  if (aliases[cleaned]) {
    return aliases[cleaned];
  }
  const partialIdx = BN_MONTHS.findIndex((m) => cleaned.includes(m));
  return partialIdx >= 0 ? partialIdx + 1 : null;
}
