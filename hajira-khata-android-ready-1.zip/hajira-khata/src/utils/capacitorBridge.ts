import {Capacitor} from '@capacitor/core';
import {Directory, Encoding, Filesystem} from '@capacitor/filesystem';
import {Share} from '@capacitor/share';

function uint8ToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const slice = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...slice);
  }
  return btoa(binary);
}

export async function copyTextToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fall back to execCommand below
  }

  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    textarea.setSelectionRange(0, textarea.value.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(textarea);
    return ok;
  } catch {
    return false;
  }
}

export async function saveAndShareFile(options: {
  filename: string;
  mimeType: string;
  data: Uint8Array | string;
}): Promise<{ok: boolean; method: 'capacitor' | 'browser'; error?: string}> {
  const {filename, mimeType, data} = options;

  try {
    if (Capacitor.isNativePlatform()) {
      const writeResult =
        typeof data === 'string'
          ? await Filesystem.writeFile({
              path: filename,
              data,
              directory: Directory.Cache,
              encoding: Encoding.UTF8,
            })
          : await Filesystem.writeFile({
              path: filename,
              data: uint8ToBase64(data),
              directory: Directory.Cache,
            });

      await Share.share({
        title: filename,
        url: writeResult.uri,
        dialogTitle: filename,
      });

      return {ok: true, method: 'capacitor'};
    }
  } catch (err) {
    return {
      ok: false,
      method: 'capacitor',
      error: err instanceof Error ? err.message : 'ফাইল সংরক্ষণ করা যায়নি।',
    };
  }

  try {
    const blobPart: BlobPart =
      typeof data === 'string' ? data : new Uint8Array(data).buffer;
    const blob = new Blob([blobPart], {type: mimeType});
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    return {ok: true, method: 'browser'};
  } catch (err) {
    return {
      ok: false,
      method: 'browser',
      error: err instanceof Error ? err.message : 'ফাইল ডাউনলোড করা যায়নি।',
    };
  }
}

export function isCapacitorNative(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}
