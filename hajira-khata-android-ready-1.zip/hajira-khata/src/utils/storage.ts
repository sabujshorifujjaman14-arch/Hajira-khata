import {HajiraState, Mark, MonthAttendance, Student} from '../types';

const STORAGE_KEY = 'hajira_khata_v1';
const IDB_NAME = 'hajira_khata_db';
const IDB_STORE = 'state_store';
const IDB_KEY = 'main';

export function createDefaultStudents(): Student[] {
  return Array.from({length: 50}, (_, index) => ({
    id: `s-${index + 1}`,
    roll: index + 1,
    name: '',
  }));
}

export function createDefaultState(): HajiraState {
  const now = new Date();
  return {
    schoolName: '',
    className: 'সপ্তম',
    month: now.getMonth() + 1,
    year: now.getFullYear(),
    students: createDefaultStudents(),
    attendance: {},
  };
}

function sanitizeMark(value: unknown): Mark | null {
  if (value === 'P' || value === 'A' || value === 'L') {
    return value;
  }
  return null;
}

export function sanitizeState(raw: unknown): HajiraState | null {
  if (!raw || typeof raw !== 'object') {
    return null;
  }
  const obj = raw as Record<string, unknown>;
  const now = new Date();

  const schoolName = typeof obj.schoolName === 'string' ? obj.schoolName : '';
  const className = typeof obj.className === 'string' ? obj.className : 'সপ্তম';
  const monthNum = typeof obj.month === 'number' && obj.month >= 1 && obj.month <= 12
    ? Math.trunc(obj.month)
    : now.getMonth() + 1;
  const yearNum = typeof obj.year === 'number' && obj.year >= 1900 && obj.year <= 2200
    ? Math.trunc(obj.year)
    : now.getFullYear();

  const students: Student[] = [];
  if (Array.isArray(obj.students)) {
    const seenIds = new Set<string>();
    for (let i = 0; i < obj.students.length; i += 1) {
      const item = obj.students[i];
      if (!item || typeof item !== 'object') continue;
      const rec = item as Record<string, unknown>;
      const id = typeof rec.id === 'string' && rec.id.trim() ? rec.id : `s-${i + 1}`;
      if (seenIds.has(id)) continue;
      seenIds.add(id);
      const roll = typeof rec.roll === 'number' && Number.isFinite(rec.roll)
        ? Math.max(1, Math.trunc(rec.roll))
        : i + 1;
      const name = typeof rec.name === 'string' ? rec.name : '';
      students.push({id, roll, name});
    }
  } else {
    students.push(...createDefaultStudents());
  }

  const attendance: Record<string, MonthAttendance> = {};
  if (obj.attendance && typeof obj.attendance === 'object') {
    for (const [monthKey, rawMonth] of Object.entries(obj.attendance as Record<string, unknown>)) {
      if (!rawMonth || typeof rawMonth !== 'object') continue;
      const monthObj = rawMonth as Record<string, unknown>;
      const marks: Record<string, Record<number, Mark>> = {};
      if (monthObj.marks && typeof monthObj.marks === 'object') {
        for (const [stuId, rawDays] of Object.entries(monthObj.marks as Record<string, unknown>)) {
          if (!rawDays || typeof rawDays !== 'object') continue;
          const cleanDays: Record<number, Mark> = {};
          for (const [dayKey, markVal] of Object.entries(rawDays as Record<string, unknown>)) {
            const d = Number.parseInt(dayKey, 10);
            const m = sanitizeMark(markVal);
            if (Number.isFinite(d) && d >= 1 && d <= 31 && m) {
              cleanDays[d] = m;
            }
          }
          if (Object.keys(cleanDays).length > 0) {
            marks[stuId] = cleanDays;
          }
        }
      }
      const hol: Record<number, boolean> = {};
      if (monthObj.hol && typeof monthObj.hol === 'object') {
        for (const [dayKey, holVal] of Object.entries(monthObj.hol as Record<string, unknown>)) {
          const d = Number.parseInt(dayKey, 10);
          if (Number.isFinite(d) && d >= 1 && d <= 31 && typeof holVal === 'boolean') {
            hol[d] = holVal;
          }
        }
      }
      attendance[monthKey] = {marks, hol};
    }
  }

  return {
    schoolName,
    className,
    month: monthNum,
    year: yearNum,
    students,
    attendance,
  };
}

export function loadState(): HajiraState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const sanitized = sanitizeState(parsed);
      if (sanitized) {
        return sanitized;
      }
    }
  } catch {
    // Ignore storage read errors and fall through to default
  }
  return createDefaultState();
}

function mirrorToIndexedDb(serialized: string): void {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return;
  }
  try {
    const req = window.indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = () => {
      try {
        const db = req.result;
        const tx = db.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).put(serialized, IDB_KEY);
        tx.oncomplete = () => db.close();
      } catch {
        // Ignore IDB transaction errors
      }
    };
  } catch {
    // Ignore IDB open errors
  }
}

export async function recoverFromIndexedDbIfEmpty(): Promise<HajiraState | null> {
  try {
    if (window.localStorage.getItem(STORAGE_KEY)) {
      return null;
    }
  } catch {
    // Continue checking IDB
  }

  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return null;
  }

  return new Promise((resolve) => {
    try {
      const req = window.indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          db.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => {
        try {
          const db = req.result;
          const tx = db.transaction(IDB_STORE, 'readonly');
          const getReq = tx.objectStore(IDB_STORE).get(IDB_KEY);
          getReq.onsuccess = () => {
            db.close();
            if (typeof getReq.result === 'string') {
              try {
                const parsed = JSON.parse(getReq.result);
                const sanitized = sanitizeState(parsed);
                if (sanitized) {
                  try {
                    window.localStorage.setItem(STORAGE_KEY, getReq.result);
                  } catch {
                    // Ignore
                  }
                  resolve(sanitized);
                  return;
                }
              } catch {
                // Ignore parse error
              }
            }
            resolve(null);
          };
          getReq.onerror = () => {
            db.close();
            resolve(null);
          };
        } catch {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export function saveState(state: HajiraState): void {
  try {
    const serialized = JSON.stringify(state);
    window.localStorage.setItem(STORAGE_KEY, serialized);
    mirrorToIndexedDb(serialized);
  } catch {
    // Ignore storage quota errors
  }
}
