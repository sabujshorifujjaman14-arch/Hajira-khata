import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const ROOT_DIR = process.cwd();
const OUT_DIR = path.join(ROOT_DIR, 'public');
const ZIP_FILENAME = 'hajira-khata-project.zip';
const OUT_PATH = path.join(OUT_DIR, ZIP_FILENAME);
const ARCHIVE_ROOT = 'hajira-khata';

const ROOT_FILES = [
  'index.html',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'vite.config.ts',
  'metadata.json',
  '.env.example',
  '.gitignore',
];

const INCLUDE_DIRS = ['src', 'public', 'scripts'];

// Standard CRC-32 table (works on any Node.js version)
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let c = i;
    for (let k = 0; k < 8; k += 1) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buf) {
  if (typeof zlib.crc32 === 'function') {
    return zlib.crc32(buf) >>> 0;
  }
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i += 1) {
    crc = CRC_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function toDosTimeDate(date) {
  const year = Math.max(1980, date.getFullYear());
  const dosTime =
    ((date.getHours() & 0x1f) << 11) |
    ((date.getMinutes() & 0x3f) << 5) |
    ((date.getSeconds() >> 1) & 0x1f);
  const dosDate =
    (((year - 1980) & 0x7f) << 9) |
    (((date.getMonth() + 1) & 0x0f) << 5) |
    (date.getDate() & 0x1f);
  return {dosTime, dosDate};
}

function collectFiles() {
  const entries = [];

  for (const rel of ROOT_FILES) {
    const abs = path.join(ROOT_DIR, rel);
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
      entries.push({abs, rel});
    }
  }

  const walk = (dirRel) => {
    const dirAbs = path.join(ROOT_DIR, dirRel);
    if (!fs.existsSync(dirAbs) || !fs.statSync(dirAbs).isDirectory()) {
      return;
    }
    const items = fs.readdirSync(dirAbs, {withFileTypes: true});
    items.sort((a, b) => a.name.localeCompare(b.name));
    for (const item of items) {
      const childRel = path.join(dirRel, item.name);
      const childAbs = path.join(ROOT_DIR, childRel);
      if (item.isDirectory()) {
        walk(childRel);
      } else if (item.isFile()) {
        if (childAbs === OUT_PATH || item.name.endsWith('.zip')) {
          continue;
        }
        entries.push({abs: childAbs, rel: childRel});
      }
    }
  };

  for (const dir of INCLUDE_DIRS) {
    walk(dir);
  }

  return entries;
}

function buildZipBuffer(entries) {
  const localChunks = [];
  const centralChunks = [];
  let offset = 0;

  for (const entry of entries) {
    const raw = fs.readFileSync(entry.abs);
    const stat = fs.statSync(entry.abs);
    const compressed = zlib.deflateRawSync(raw, {level: 9});
    const crc = crc32(raw);
    const {dosTime, dosDate} = toDosTimeDate(stat.mtime);

    const zipName = path.posix.join(
      ARCHIVE_ROOT,
      entry.rel.split(path.sep).join(path.posix.sep),
    );
    const nameBuf = Buffer.from(zipName, 'utf8');

    // Local File Header (30 bytes + filename)
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0); // signature
    localHeader.writeUInt16LE(20, 4); // version needed (2.0)
    localHeader.writeUInt16LE(0x0800, 6); // UTF-8 filename flag
    localHeader.writeUInt16LE(8, 8); // compression method: deflate
    localHeader.writeUInt16LE(dosTime, 10);
    localHeader.writeUInt16LE(dosDate, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(compressed.length, 18);
    localHeader.writeUInt32LE(raw.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28); // extra len

    localChunks.push(localHeader, nameBuf, compressed);

    // Central Directory Header (46 bytes + filename)
    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0); // signature
    centralHeader.writeUInt16LE(20, 4); // version made by
    centralHeader.writeUInt16LE(20, 6); // version needed
    centralHeader.writeUInt16LE(0x0800, 8); // UTF-8 flag
    centralHeader.writeUInt16LE(8, 10); // deflate
    centralHeader.writeUInt16LE(dosTime, 12);
    centralHeader.writeUInt16LE(dosDate, 14);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(compressed.length, 20);
    centralHeader.writeUInt32LE(raw.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30); // extra len
    centralHeader.writeUInt16LE(0, 32); // comment len
    centralHeader.writeUInt16LE(0, 34); // disk start
    centralHeader.writeUInt16LE(0, 36); // internal attrs
    centralHeader.writeUInt32LE(0, 38); // external attrs
    centralHeader.writeUInt32LE(offset, 42); // relative offset

    centralChunks.push(centralHeader, nameBuf);
    offset += localHeader.length + nameBuf.length + compressed.length;
  }

  const centralSize = centralChunks.reduce((sum, b) => sum + b.length, 0);

  // End of Central Directory Record (22 bytes)
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralSize, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localChunks, ...centralChunks, eocd]);
}

function main() {
  fs.mkdirSync(OUT_DIR, {recursive: true});
  const entries = collectFiles();
  const zipBuffer = buildZipBuffer(entries);
  fs.writeFileSync(OUT_PATH, zipBuffer);

  const appUrl = (process.env.APP_URL || '').replace(/\/+$/, '');
  const downloadPath = `/${ZIP_FILENAME}`;
  const fullUrl = appUrl ? `${appUrl}${downloadPath}` : downloadPath;

  console.log(`প্যাকেজ সম্পন্ন: ${entries.length}টি ফাইল -> ${OUT_PATH}`);
  console.log(`মোট সাইজ: ${(zipBuffer.length / 1024).toFixed(2)} KB`);
  console.log(`ডাউনলোড লিংক: ${fullUrl}`);
}

main();
